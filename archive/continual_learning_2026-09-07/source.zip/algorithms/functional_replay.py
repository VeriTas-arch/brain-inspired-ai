"""Bounded actor distillation memory; stored data are never used as PPO rollouts."""

import torch
import torch.nn.functional as F

from .ppo import MultiHeadPPOAgent


class PolicyMemory:
    """Keep equal per-task quotas of observations and immutable teacher logits.

    Task IDs are the dictionary keys, allowing tasks with different action counts.
    Both admission and sampling use a private CPU generator.
    """

    def __init__(self, capacity: int, *, seed: int):
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self.generator = torch.Generator().manual_seed(seed)
        self.tasks: dict[str, tuple[torch.Tensor, torch.Tensor]] = {}

    def add_task(self, task_id: str, observations: torch.Tensor, logits: torch.Tensor) -> None:
        """Admit one completed task, subsampling every task to its new quota."""
        if task_id in self.tasks:
            raise ValueError("A completed task can be admitted only once")
        if observations.dtype != torch.uint8:
            raise ValueError("memory observations must be uint8")
        if logits.ndim != 2 or not len(logits) or len(observations) != len(logits):
            raise ValueError("observations and logits must have matching nonempty batches")
        quota = self.capacity // (len(self.tasks) + 1)
        if quota == 0:
            raise ValueError("capacity must retain at least one observation per task")
        self.tasks[task_id] = (observations.detach().cpu(), logits.detach().float().cpu())
        for task, (states, teacher) in self.tasks.items():
            indices = torch.randperm(len(states), generator=self.generator)[:quota]
            self.tasks[task] = (states[indices].clone(), teacher[indices].clone())

    def sample(self, batch_size: int) -> list[tuple[str, torch.Tensor, torch.Tensor]]:
        """Sample tasks uniformly, then states uniformly within each selected task."""
        if not self.tasks or batch_size <= 0:
            raise ValueError("sampling requires nonempty memory and a positive batch size")
        tasks = list(self.tasks)
        counts = torch.bincount(
            torch.randint(len(tasks), (batch_size,), generator=self.generator),
            minlength=len(tasks),
        )
        samples = []
        for task, count in zip(tasks, counts.tolist(), strict=True):
            if count:
                states, teacher = self.tasks[task]
                indices = torch.randint(len(states), (count,), generator=self.generator)
                samples.append((task, states[indices], teacher[indices]))
        return samples

    @property
    def tensor_bytes(self) -> int:
        """Persistent tensor storage, excluding small Python task metadata."""
        return sum(x.numel() * x.element_size() for pair in self.tasks.values() for x in pair)

    def state_dict(self) -> dict:
        return {
            "capacity": self.capacity,
            "tasks": {task: tuple(x.clone() for x in pair) for task, pair in self.tasks.items()},
            "rng_state": self.generator.get_state(),
        }

    @classmethod
    def from_state_dict(cls, state: dict) -> "PolicyMemory":
        memory = cls(state["capacity"], seed=0)
        memory.tasks = {
            task: tuple(x.detach().cpu().clone() for x in pair)
            for task, pair in state["tasks"].items()
        }
        memory.generator.set_state(state["rng_state"].cpu())
        return memory


def policy_replay_loss(
    agent: MultiHeadPPOAgent, memory: PolicyMemory, *, batch_size: int, weight: float
) -> torch.Tensor:
    """Differentiate KL(teacher || student) through backbone and old actors only."""
    total = torch.zeros((), device=agent.device)
    for task, states, teacher in memory.sample(batch_size):
        student = agent.policy_logits(states.to(agent.device), task)
        total = total + F.kl_div(
            student.log_softmax(-1),
            teacher.to(agent.device).log_softmax(-1),
            reduction="sum",
            log_target=True,
        )
    return weight * total / batch_size
