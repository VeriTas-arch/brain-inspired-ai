"""Boundary-policy diagonal Fisher with exact marginalization over discrete actions."""

import torch
from torch.func import functional_call, jacrev, vmap

from .ewc import EWCWrapper


def estimate_policy_fisher(backbone, actor, states, *, batch_size: int = 8, seed: int = 0):
    """Return action-exact and one-action MC estimates on identical states.

    Only backbone parameters are differentiated. Two fixed random halves allow
    state/action sampling variability to be measured without using the eval probe.
    """
    params = {name: p.detach() for name, p in backbone.named_parameters()}
    actor_params = {name: p.detach() for name, p in actor.named_parameters()}
    device = next(backbone.parameters()).device
    dtype = next(backbone.parameters()).dtype
    generator = torch.Generator().manual_seed(seed)
    order = torch.randperm(len(states), generator=generator)
    totals = {
        method: [
            {name: torch.zeros_like(p, dtype=torch.float64) for name, p in params.items()}
            for _ in range(2)
        ]
        for method in ("expected", "sampled")
    }
    counts = [0, 0]

    def log_policy(parameters, state):
        features = functional_call(backbone, parameters, (state.unsqueeze(0).to(dtype) / 255.0,))
        log_probs = functional_call(actor, actor_params, (features,)).log_softmax(-1).squeeze(0)
        return log_probs, log_probs.detach().exp()

    per_state_jacobian = vmap(jacrev(log_policy, has_aux=True), in_dims=(None, 0))
    for half, indices in enumerate(order.tensor_split(2)):
        for chunk in indices.split(batch_size):
            gradients, probabilities = per_state_jacobian(params, states[chunk].to(device))
            actions = (
                torch.multinomial(probabilities.cpu(), 1, generator=generator).flatten().to(device)
            )
            rows = torch.arange(len(chunk), device=device)
            with torch.no_grad():
                for name, gradient in gradients.items():
                    shape = (*probabilities.shape, *((1,) * params[name].ndim))
                    expected = (gradient.square() * probabilities.reshape(shape)).sum((0, 1))
                    sampled = gradient[rows, actions].square().sum(0)
                    totals["expected"][half][name].add_(expected)
                    totals["sampled"][half][name].add_(sampled)
            counts[half] += len(chunk)
    result = {}
    for method, halves in totals.items():
        result[method] = {
            name: ((halves[0][name] + halves[1][name]) / len(states)).float().cpu()
            for name in params
        }
        result[f"{method}_halves"] = [
            {name: (value / count).float().cpu() for name, value in half.items()}
            for half, count in zip(halves, counts, strict=True)
        ]
    return result


class ExpectedFisherEWC(EWCWrapper):
    """Use precomputed shared-backbone importance with the existing EWC learner."""

    def __init__(self, agent, importance: dict, *, ewc_lambda: float):
        super().__init__(agent, ewc_lambda=ewc_lambda)
        fisher = {f"backbone.{name}": value.to(agent.device) for name, value in importance.items()}
        params = self._collect_regularized_params()
        weights = {name: params[name].detach().clone() for name in fisher}
        self.task_weights[0], self.task_fisher[0] = weights, fisher
        self._accumulate_task(weights, fisher)
        self.current_task_id = 1
        self._reset_runtime_regularizer()
