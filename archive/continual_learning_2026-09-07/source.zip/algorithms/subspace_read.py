"""Task-specific diagonal reuse of a frozen GPM input subspace.

This is a single-layer diagonal adaptation of TRGP's scaled weight projection,
not a reproduction of its full matrices or task-selection algorithm.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from algorithms.ppo import MultiHeadPPOAgent
from algorithms.subspace_projection import affine_matrix


class SubspaceReadLinear(nn.Linear):
    """Keep the original affine parameters and add W_anchor U diag(a) U.T."""

    def __init__(self, layer: nn.Linear, basis: torch.Tensor):
        # Retain parameter identities and RNG state, including inherited Adam moments.
        nn.Module.__init__(self)
        self.in_features, self.out_features = layer.in_features, layer.out_features
        self.weight, self.bias = layer.weight, layer.bias
        self.register_buffer("basis", basis.detach().to(layer.weight).clone())
        self.register_buffer("read_weights", (affine_matrix(layer).detach() @ self.basis).clone())
        self.scaling = nn.Parameter(layer.weight.new_zeros(basis.shape[1]))
        self.enabled = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output = F.linear(x, self.weight, self.bias)
        if not self.enabled:
            return output
        augmented = x
        if self.bias is not None:
            augmented = torch.cat((x, torch.ones_like(x[..., :1])), dim=-1)
        return output + F.linear((augmented @ self.basis) * self.scaling, self.read_weights)


class SubspaceReadPPOAgent(MultiHeadPPOAgent):
    """Two-task PPO candidate: only the new task uses the last-layer scaling."""

    def add_read_scaling(self, basis: torch.Tensor, task_id: str) -> None:
        self.backbone[7] = SubspaceReadLinear(self.backbone[7], basis)
        self.scaled_task = task_id
        self.optimizer.add_param_group({"params": [self.backbone[7].scaling]})
        self.backbone[7].enabled = self.current_task == task_id

    def set_task(self, task_id: str) -> None:
        super().set_task(task_id)
        if hasattr(self, "scaled_task"):
            self.backbone[7].enabled = task_id == self.scaled_task

    def policy_logits(self, states: torch.Tensor, task_id: str) -> torch.Tensor:
        if not hasattr(self, "scaled_task"):
            return super().policy_logits(states, task_id)
        layer = self.backbone[7]
        previous = layer.enabled
        layer.enabled = task_id == self.scaled_task
        try:
            return super().policy_logits(states, task_id)
        finally:
            layer.enabled = previous

    def checkpoint_state(self) -> dict:
        state = super().checkpoint_state()
        if hasattr(self, "scaled_task"):
            state["scaled_task"] = self.scaled_task
        return state

    def load_checkpoint_state(self, checkpoint: dict) -> None:
        if "scaled_task" not in checkpoint:
            super().load_checkpoint_state(checkpoint)
            return
        # Restore baseline parameter groups before appending the scaling group.
        extra = {f"7.{name}" for name in ("basis", "read_weights", "scaling")}
        baseline = {
            **checkpoint,
            "backbone": {k: v for k, v in checkpoint["backbone"].items() if k not in extra},
            "optimizer": None,
        }
        super().load_checkpoint_state(baseline)
        self.add_read_scaling(checkpoint["backbone"]["7.basis"], checkpoint["scaled_task"])
        self.backbone.load_state_dict(checkpoint["backbone"])
        if checkpoint.get("optimizer") is not None:
            self.optimizer.load_state_dict(checkpoint["optimizer"])
