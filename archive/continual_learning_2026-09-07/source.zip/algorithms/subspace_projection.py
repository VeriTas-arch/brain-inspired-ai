"""Boundary input subspaces and projection of actual Adam steps for two-task PPO.

GPM uses unit importance; SGP uses Saha & Roy (2023), equation 2. Biases are
included as an extra input coordinate, preserving the existing Atari network.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def affine_layers(backbone: nn.Module) -> dict[str, nn.Module]:
    return {
        name: layer
        for name, layer in backbone.named_modules()
        if isinstance(layer, (nn.Conv2d, nn.Linear))
    }


@torch.no_grad()
def build_input_subspaces(
    backbone: nn.Module,
    observations: torch.Tensor,
    *,
    threshold: float,
    alpha: float,
    seed: int,
    batch_size: int = 32,
    patches_per_observation: int = 16,
) -> dict:
    """Compute uncentered SVD bases via float64 second moments at a task boundary.

    Convolution inputs are sampled receptive-field patches with a private RNG.
    No teacher logits, rewards, or held-out policy probes enter this calculation.
    This study estimates one completed task; it does not implement multi-task
    SGP importance accumulation.
    """
    if not 0 < threshold <= 1 or alpha < 0:
        raise ValueError("Require threshold in (0, 1] and nonnegative alpha")
    if observations.dtype != torch.uint8 or not len(observations):
        raise ValueError("Require nonempty uint8 observations")
    layers = affine_layers(backbone)
    device = next(backbone.parameters()).device
    generator = torch.Generator().manual_seed(seed)
    moments, counts, handles = {}, {}, []

    def capture(name, layer, inputs):
        x = inputs[0]
        if isinstance(layer, nn.Conv2d):
            x = F.unfold(
                x, layer.kernel_size, layer.dilation, layer.padding, layer.stride
            ).transpose(1, 2)
            indices = torch.randint(
                x.shape[1], (len(x), patches_per_observation), generator=generator
            ).to(device)
            x = x.gather(1, indices.unsqueeze(-1).expand(-1, -1, x.shape[-1]))
        x = x.reshape(-1, x.shape[-1]).double()
        if layer.bias is not None:
            x = torch.cat((x, torch.ones(len(x), 1, device=device, dtype=x.dtype)), dim=1)
        if name not in moments:
            moments[name] = torch.zeros(x.shape[1], x.shape[1], dtype=x.dtype, device=device)
            counts[name] = 0
        moments[name].addmm_(x.T, x)
        counts[name] += len(x)

    try:
        for name, layer in layers.items():
            handles.append(
                layer.register_forward_pre_hook(
                    lambda module, inputs, name=name: capture(name, module, inputs)
                )
            )
        for batch in observations.split(batch_size):
            backbone(batch.to(device).float() / 255.0)
    finally:
        for handle in handles:
            handle.remove()

    result = {}
    for name, moment in moments.items():
        eigenvalues, basis = torch.linalg.eigh(moment)
        energy = eigenvalues.flip(0).clamp_min(0)
        rank = min(
            int(torch.searchsorted(energy.cumsum(0), threshold * energy.sum())) + 1,
            len(energy),
        )
        singular = energy[:rank].sqrt()
        importance = (alpha + 1) * singular / (alpha * singular + singular[0])
        result[name] = {
            "basis": basis.flip(1)[:, :rank].float().cpu().contiguous(),
            "importance": importance.float().cpu(),
            "singular_values": singular.cpu(),
            "dimension": len(energy),
            "rank": rank,
            "captured_energy_fraction": float(energy[:rank].sum() / energy.sum()),
            "sample_count": counts[name],
        }
    return result


def affine_matrix(layer: nn.Module) -> torch.Tensor:
    weight = layer.weight.flatten(1)
    return weight if layer.bias is None else torch.cat((weight, layer.bias[:, None]), dim=1)


class AdamSubspaceProjection:
    """Project optimizer displacements after Adam's moment scaling, not raw grads.

    Hooks leave Adam's moments and the existing PPO learner unchanged. Computing
    the displacement from pre/post weights introduces only floating-point rounding;
    the realized projection error is measured on every update. Only the shared
    affine layers are projected, including their biases.
    """

    def __init__(self, optimizer, backbone: nn.Module, subspaces: dict, *, method: str):
        if method not in {"gpm", "sgp"}:
            raise ValueError("method must be gpm or sgp")
        self.layers = affine_layers(backbone)
        self.bases, self.importance, self.before, self.sums = {}, {}, {}, {}
        self.steps = 0
        for name, layer in self.layers.items():
            self.bases[name] = subspaces[name]["basis"].to(layer.weight)
            importance = subspaces[name]["importance"].to(layer.weight)
            self.importance[name] = torch.ones_like(importance) if method == "gpm" else importance
            self.sums[name] = torch.zeros(4, device=layer.weight.device, dtype=torch.float64)
        self.handles = (
            optimizer.register_step_pre_hook(self._before_step),
            optimizer.register_step_post_hook(self._after_step),
        )

    @torch.no_grad()
    def _before_step(self, optimizer, args, kwargs):
        self.before = {name: affine_matrix(layer).clone() for name, layer in self.layers.items()}

    @torch.no_grad()
    def _after_step(self, optimizer, args, kwargs):
        for name, layer in self.layers.items():
            before, basis = self.before[name], self.bases[name]
            delta = affine_matrix(layer) - before
            coordinates = delta @ basis
            projected = delta - (coordinates * self.importance[name]) @ basis.T
            updated = before + projected
            width = layer.weight[0].numel()
            layer.weight.copy_(updated[:, :width].reshape_as(layer.weight))
            if layer.bias is not None:
                layer.bias.copy_(updated[:, -1])
            applied = affine_matrix(layer) - before
            protected = applied @ basis
            error = protected - coordinates * (1 - self.importance[name])
            self.sums[name] += torch.stack(
                [x.square().sum().double() for x in (delta, applied, protected, error)]
            )
        self.steps += 1
        self.before.clear()

    def metrics(self) -> dict:
        result = {}
        for name, values in self.sums.items():
            raw, applied, protected, error = values.tolist()
            result[name] = {
                "raw_update_energy": raw,
                "retained_update_energy_fraction": applied / raw if raw else 0,
                "protected_update_energy_fraction": protected / raw if raw else 0,
                "projection_relative_error": (error / raw) ** 0.5 if raw else 0,
            }
        return {"optimizer_steps": self.steps, "layers": result}

    def close(self) -> None:
        for handle in self.handles:
            handle.remove()
