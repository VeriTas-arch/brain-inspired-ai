"""Audit the frozen Fisher diagnostic and report its admission decision."""

import json
from pathlib import Path

import matplotlib
import numpy as np
import torch

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from scripts.study_expected_fisher import cosine, vector  # noqa: E402
from scripts.study_policy_replay import ROOT, write_json  # noqa: E402
from scripts.study_subspace import file_hash  # noqa: E402


def main():
    torch.set_num_threads(1)
    root = ROOT / "outputs/expected_fisher_v1/seed-61001"
    manifest = json.loads((root / "manifest.json").read_text())
    settings = json.loads((ROOT / "experiments/expected_fisher_v1.json").read_text())
    assert manifest["settings"] == settings
    assert manifest["seed"] == 61001 and manifest["device"] == "cuda"
    source = ROOT / settings["anchor_dir"]
    assert manifest["anchor_sha256"] == file_hash(source / "anchor.pt")
    original = json.loads((source / "manifest.json").read_text())
    assert manifest["protocol"] == original["config"]
    for name, digest in manifest["source_sha256"].items():
        assert file_hash(ROOT / name) == digest, name
        assert file_hash(root / "source_snapshot" / name) == digest, name
    for name, digest in original["source_sha256"].items():
        if name != "scripts/run_experiments.py":
            assert manifest["source_sha256"][name] == digest, name
    assert file_hash(root / "protocol.md") == file_hash(ROOT / "experiments/expected_fisher_v1.md")
    estimates = torch.load(root / "fisher_estimates.pt", map_location="cpu", weights_only=True)
    scaled = torch.load(root / "training_fisher.pt", map_location="cpu", weights_only=True)
    diagnostic = json.loads((root / "diagnostics.json").read_text())
    assert diagnostic["state_count"] == 2048 and diagnostic["action_count"] == 6
    trace = {
        method: float(vector(estimates[method]).sum())
        for method in ("legacy", "sampled", "expected")
    }
    for method, value in trace.items():
        assert np.isclose(value, diagnostic["trace"][method])
    half_cosine = {}
    for method in ("expected", "sampled"):
        half_cosine[method] = cosine(*estimates[f"{method}_halves"])
        assert half_cosine[method] == diagnostic["half_cosine"][method]
        for name, value in estimates[method].items():
            halves = estimates[f"{method}_halves"]
            torch.testing.assert_close(
                value, (halves[0][name] + halves[1][name]) / 2, atol=1e-8, rtol=1e-6
            )
    scale = trace["legacy"] / trace["expected"]
    assert scale == diagnostic["training_fisher_scale"]
    for name in scaled:
        torch.testing.assert_close(
            scaled[name], estimates["expected"][name] * scale, rtol=0, atol=0
        )
    assert np.isclose(float(vector(scaled).sum()), trace["legacy"], rtol=1e-6)
    rows = diagnostic["perturbations"]["rows"]
    assert diagnostic["perturbations"]["states"] == settings["diagnostic_states"]
    assert len(rows) == (settings["random_directions"] + 4) * len(settings["relative_radii"])
    assert [(r["direction"], r["radius"]) for r in rows] == [
        (i, radius)
        for i in range(settings["random_directions"] + 4)
        for radius in settings["relative_radii"]
    ]
    errors = {}
    for method in trace:
        ratios = np.array([np.log(r["predicted_kl"][method] / r["actual_kl"]) for r in rows])
        assert np.isfinite(ratios).all()
        errors[method] = {
            "median_absolute_log_error": float(np.median(np.abs(ratios))),
            "median_log_scale_error": float(np.median(ratios)),
            "shape_error": float(np.median(np.abs(ratios - np.median(ratios)))),
        }
        assert errors[method] == diagnostic["perturbations"]["errors"][method]
    f = vector(estimates["expected"])
    checks = {
        "finite_nonnegative_positive_trace": bool(
            torch.isfinite(f).all() and (f >= 0).all() and f.sum() > 0
        ),
        "half_consistency_not_worse_than_mc": half_cosine["expected"] >= half_cosine["sampled"],
        "shape_error_reduced": errors["expected"]["shape_error"]
        <= (1 - settings["minimum_shape_error_reduction"]) * errors["legacy"]["shape_error"],
    }
    assert checks == diagnostic["checks"] and all(checks.values()) == diagnostic["admitted"]
    assert not diagnostic["admitted"]
    assert json.loads((root / "completion.json").read_text()) == {
        "status": "diagnostic_rejected",
        "trained": False,
    }
    assert not (root / "ewc_expected").exists()
    improvement = 1 - errors["expected"]["shape_error"] / errors["legacy"]["shape_error"]
    audit = {
        "status": "passed",
        "trained": False,
        "admission_checks": checks,
        "shape_error_reduction_fraction": improvement,
        "legacy_expected_cosine": cosine(estimates["legacy"], estimates["expected"]),
        "shared_training_trace_matched": True,
        "diagnostic_point_count": len(rows),
        "config_source_anchor_and_snapshot_verified": True,
    }
    write_json(root / "audit.json", audit)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4), constrained_layout=True)
    for method in trace:
        axes[0].scatter(
            [r["actual_kl"] for r in rows],
            [r["predicted_kl"][method] for r in rows],
            label=method,
            alpha=0.65,
            s=18,
        )
    limits = [min(r["actual_kl"] for r in rows), max(r["actual_kl"] for r in rows)]
    axes[0].plot(limits, limits, color="black", linestyle="--", linewidth=1)
    axes[0].set(
        xscale="log",
        yscale="log",
        xlabel="Measured policy KL",
        ylabel="Diagonal Fisher prediction",
        title="Fixed memory perturbations",
    )
    axes[0].legend()
    axes[0].grid(alpha=0.2)
    values = [errors[m]["shape_error"] for m in trace]
    axes[1].bar(list(trace), values)
    threshold = errors["legacy"]["shape_error"] * (1 - settings["minimum_shape_error_reduction"])
    axes[1].axhline(
        threshold, color="red", linestyle="--", label="10% reduction admission threshold"
    )
    for i, value in enumerate(values):
        axes[1].text(i, value + 0.002, f"{value:.4f}", ha="center")
    axes[1].set(
        ylabel="Median centered absolute log error",
        title="Prediction shape error (lower is better)",
        ylim=(0, max(values) * 1.3),
    )
    axes[1].legend(fontsize=8)
    fig.suptitle("Boundary-policy Fisher diagnostics — seed 61001")
    for extension in ("png", "svg"):
        fig.savefig(root.parent / f"diagnostics.{extension}", dpi=180)
    plt.close(fig)
    lines = [
        "# 期望 Fisher 单 seed 诊断结果",
        "",
        "期望 Fisher 更稳定，但未达到预先规定的 KL 预测改善准入条件，因此没有新增长预算 PPO 训练。不能据此断言该 EWC 变体的任务成绩更差；这轮检验的是估计质量及是否值得继续训练。",
        "",
        "原估计使用最后 rollout 的 100 个状态-动作样本；MC 和期望估计使用同一批 2048 条训练 memory 状态，动作来自边界 Pong 策略；期望估计枚举全部 6 个动作。独立 probe 没有参与估计、诊断或准入。",
        "",
        "| 估计 | 共享 Fisher trace | 原始 KL 预测误差 | 去尺度形状误差 | 分半余弦 |",
        "|---|---:|---:|---:|---:|",
    ]
    for method in trace:
        half = f"{half_cosine[method]:.6f}" if method in half_cosine else "—"
        lines.append(
            f"| {method} | {trace[method]:.4f} | {errors[method]['median_absolute_log_error']:.6f} | {errors[method]['shape_error']:.6f} | {half} |"
        )
    lines += [
        "",
        f"期望估计的形状误差降低 {100 * improvement:.2f}%，低于冻结门槛 10%；其原始中位绝对 log 误差反而更高。不能只凭分半一致性提升就认定其更接近策略功能。",
        "",
        f"原估计与期望估计的向量余弦为 {audit['legacy_expected_cosine']:.6f}；同状态 MC 与期望估计的余弦为 {diagnostic['sampled_expected_cosine']:.6f}。匹配原共享 trace 只需乘以 {scale:.6f}，对应等效 lambda {diagnostic['effective_lambda']:.6f}（原值 0.4）。没有发现原 Fisher 整体小了几个数量级的现象。",
        "",
        f"![diagnostics]({root.parent / 'diagnostics.png'})",
        "",
        "## 诊断边界",
        "",
        "采用 8 个全局随机方向、4 个单层随机方向及 3 个固定相对扰动半径，共 36 个点，在训练 memory 中的 256 个固定状态上用 float64 网络测量 KL。原始误差为 median(abs(log(predicted/actual)))；形状误差为减去该 log 比值中位数后的 median absolute deviation。后者去除整体尺度影响，但不能替代实际 PPO 轨迹或任务分数。",
        "",
        "10% 是事先固定的计算资源准入标准，不是统计显著性或算法无效的界限。这里没有测试新任务梯度方向上的完整曲率，也没有证明提高 Fisher 精度在所有情况下无效。",
        "",
        "## 决策与审计",
        "",
        "保持当前 GPM 主候选，结束这个期望 Fisher 候选的本轮测试。尚无此变体的新任务训练成绩，效果结论限于上述诊断。",
        "",
        f"原 Fisher 估计耗时 {diagnostic['legacy_seconds']:.3f} 秒；期望与 MC 联合估计耗时 {diagnostic['expected_and_mc_seconds']:.3f} 秒（含诊断半集统计，不是独立吞吐基准）。",
        "",
        "audit.json 验证了源代码、配置、Pong anchor 与快照，重算 Fisher trace、半集一致性、36 个扰动点误差、尺度匹配和准入结论，并确认不存在新增训练分支。",
        "",
        "解析测试覆盖 categorical-linear 的已知 Fisher 对角、高置信策略中罕见动作的贡献，以及原 EWC 二次损失和 Adam 状态保持。[冻结协议](expected_fisher_v1.md)。",
    ]
    (ROOT / "experiments/expected_fisher_v1_results.md").write_text("\n".join(lines) + "\n")
    (root / "report_source.py").write_bytes(Path(__file__).read_bytes())
    (root / "report_source.sha256").write_text(file_hash(Path(__file__)) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
