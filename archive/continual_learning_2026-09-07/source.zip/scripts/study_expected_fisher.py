"""Diagnose action-exact Fisher, then conditionally run one paired EWC branch."""

import argparse
import copy
import gc
import json
import time
from pathlib import Path

import numpy as np
import torch

from algorithms.ewc import EWCWrapper, summarize_parameter_importance
from algorithms.expected_fisher import ExpectedFisherEWC, estimate_policy_fisher
from algorithms.functional_replay import PolicyMemory
from scripts.study_policy_replay import (
    NEW,
    OLD,
    ROOT,
    evaluate,
    new_agent,
    normalized_auc,
    policy_diagnostics,
    source_hashes,
    train_stage,
    write_json,
)
from scripts.study_subspace import file_hash
from training import configure_ppo_runtime
from utils import seed_everything


def vector(importance):
    return torch.cat([value.double().flatten() for value in importance.values()])


def cosine(first, second):
    a, b = vector(first), vector(second)
    return float(torch.dot(a, b) / (a.norm() * b.norm()))


def perturbation_diagnostics(agent, memory_states, estimates, settings, seed):
    """Compare local policy KL on training memory; never read the eval probe."""
    backbone = copy.deepcopy(agent.backbone).double()
    actor = copy.deepcopy(agent.actors[OLD]).double()
    params = dict(backbone.named_parameters())
    means = {name: p.detach().clone() for name, p in params.items()}
    generator = torch.Generator().manual_seed(seed + 51000)
    indices = torch.randperm(len(memory_states), generator=generator)[
        : settings["diagnostic_states"]
    ]
    states = memory_states[indices].to(device=agent.device, dtype=torch.float64) / 255

    def log_probs():
        return torch.cat([actor(backbone(chunk)).log_softmax(-1) for chunk in states.split(32)])

    with torch.no_grad():
        teacher = log_probs()
        groups = list(dict.fromkeys(name.split(".")[0] for name in params))
        rows = []
        for index, group in enumerate([None] * settings["random_directions"] + groups):
            direction = {
                name: torch.randn(p.shape, dtype=torch.float64, generator=generator).to(p.device)
                if group is None or name.split(".")[0] == group
                else torch.zeros_like(p)
                for name, p in params.items()
            }
            norm = sum(d.square().sum() for d in direction.values()).sqrt()
            target = sum(
                p.square().sum()
                for name, p in means.items()
                if group is None or name.split(".")[0] == group
            ).sqrt()
            direction = {name: d * (target / norm) for name, d in direction.items()}
            quadratic = {
                method: 0.5
                * sum(
                    float((values[name].double().to(d.device) * d.square()).sum())
                    for name, d in direction.items()
                )
                for method, values in estimates.items()
            }
            for radius in settings["relative_radii"]:
                for name, p in params.items():
                    p.copy_(means[name] + radius * direction[name])
                actual = float((teacher.exp() * (teacher - log_probs())).sum(-1).mean())
                if not actual > 0:
                    raise ValueError(
                        f"Nonpositive diagnostic KL at direction {index}, radius {radius}"
                    )
                rows.append(
                    {
                        "direction": index,
                        "group": group or "all",
                        "radius": radius,
                        "actual_kl": actual,
                        "predicted_kl": {m: q * radius**2 for m, q in quadratic.items()},
                    }
                )
    errors = {}
    for method in estimates:
        ratios = np.array([np.log(row["predicted_kl"][method] / row["actual_kl"]) for row in rows])
        errors[method] = {
            "median_absolute_log_error": float(np.median(np.abs(ratios))),
            "median_log_scale_error": float(np.median(ratios)),
            "shape_error": float(np.median(np.abs(ratios - np.median(ratios)))),
        }
    return {"states": len(states), "rows": rows, "errors": errors}


def diagnose(anchor, settings, seed, device, output):
    agent = new_agent(device)
    agent.load_checkpoint_state(copy.deepcopy(anchor["agent"]))
    agent.set_task(OLD)
    started = time.perf_counter()
    legacy = EWCWrapper(agent).compute_parameter_importance(anchor["last_rollout"])
    legacy = {
        name.removeprefix("backbone."): value.cpu()
        for name, value in legacy.items()
        if name.startswith("backbone.")
    }
    legacy_seconds = time.perf_counter() - started
    states = anchor["memory"]["tasks"][OLD][0]
    started = time.perf_counter()
    estimates = estimate_policy_fisher(
        agent.backbone,
        agent.actors[OLD],
        states,
        batch_size=settings["fisher_batch_size"],
        seed=seed + 50000,
    )
    expected_seconds = time.perf_counter() - started
    torch.save({"legacy": legacy, **estimates}, output / "fisher_estimates.pt")
    candidates = {
        "legacy": legacy,
        "sampled": estimates["sampled"],
        "expected": estimates["expected"],
    }
    trace = {method: float(vector(values).sum()) for method, values in candidates.items()}
    scale = trace["legacy"] / trace["expected"]
    quality = perturbation_diagnostics(agent, states, candidates, settings, seed)
    stability = {
        method: cosine(*estimates[f"{method}_halves"]) for method in ("expected", "sampled")
    }
    expected = vector(estimates["expected"])
    checks = {
        "finite_nonnegative_positive_trace": bool(
            torch.isfinite(expected).all() and (expected >= 0).all() and expected.sum() > 0
        ),
        "half_consistency_not_worse_than_mc": stability["expected"] >= stability["sampled"],
        "shape_error_reduced": quality["errors"]["expected"]["shape_error"]
        <= (1 - settings["minimum_shape_error_reduction"])
        * quality["errors"]["legacy"]["shape_error"],
    }
    report = {
        "admitted": all(checks.values()),
        "checks": checks,
        "state_count": len(states),
        "action_count": agent.actors[OLD].out_features,
        "trace": trace,
        "training_fisher_scale": scale,
        "effective_lambda": 0.4 * scale,
        "half_cosine": stability,
        "sampled_expected_cosine": cosine(estimates["sampled"], estimates["expected"]),
        "sampled_relative_l2_error": float(
            (vector(estimates["sampled"]) - expected).norm() / expected.norm()
        ),
        "layers": {
            method: summarize_parameter_importance(values) for method, values in candidates.items()
        },
        "legacy_seconds": legacy_seconds,
        "expected_and_mc_seconds": expected_seconds,
        "perturbations": quality,
    }
    write_json(output / "diagnostics.json", report)
    torch.save(
        {name: value * scale for name, value in estimates["expected"].items()},
        output / "training_fisher.pt",
    )
    print(
        json.dumps({k: v for k, v in report.items() if k not in {"layers", "perturbations"}}),
        flush=True,
    )
    print(json.dumps({"prediction_errors": quality["errors"]}), flush=True)
    return report


def run_study(settings, seed, *, diagnostics_only=False):
    source = ROOT / settings["anchor_dir"]
    original = json.loads((source / "manifest.json").read_text())
    if seed != settings["seed"] or seed != original["seed"]:
        raise ValueError("Use the single frozen anchor seed")
    config = original["config"].copy()
    if settings.get("smoke", False):
        config.update(new_steps=1024, eval_interval=1024, eval_episodes=1)
    configure_ppo_runtime(config["env_backend"])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    output = ROOT / settings["output_dir"] / f"seed-{seed}"
    output.mkdir(parents=True, exist_ok=True)
    hashes = source_hashes()
    hashes["scripts/study_expected_fisher.py"] = file_hash(Path(__file__))
    hashes["scripts/study_subspace.py"] = file_hash(ROOT / "scripts/study_subspace.py")
    for name, digest in original["source_sha256"].items():
        if name != "scripts/run_experiments.py" and hashes[name] != digest:
            raise ValueError(f"Frozen PPO/EWC/evaluation source changed: {name}")
    manifest = {
        "settings": settings,
        "protocol": config,
        "seed": seed,
        "anchor_sha256": file_hash(source / "anchor.pt"),
        "source_sha256": hashes,
        "device": device,
        "torch": torch.__version__,
    }
    if (output / "manifest.json").exists():
        if json.loads((output / "manifest.json").read_text()) != manifest:
            raise ValueError("Study source/config changed; use a new output directory")
    else:
        write_json(output / "manifest.json", manifest)
        for name in hashes:
            snapshot = output / "source_snapshot" / name
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes((ROOT / name).read_bytes())
        (output / "protocol.md").write_bytes(
            (ROOT / "experiments/expected_fisher_v1.md").read_bytes()
        )
    anchor = torch.load(source / "anchor.pt", map_location="cpu", weights_only=True)
    diagnostics_dir = ROOT / settings.get("diagnostics_dir", str(output))
    if not (diagnostics_dir / "diagnostics.json").exists():
        diagnostic = diagnose(anchor, settings, seed, device, diagnostics_dir)
    else:
        diagnostic = json.loads((diagnostics_dir / "diagnostics.json").read_text())
    if not diagnostic["admitted"]:
        write_json(output / "completion.json", {"status": "diagnostic_rejected", "trained": False})
        return
    if diagnostics_only:
        return
    destination = output / "ewc_expected"
    destination.mkdir(exist_ok=True)
    if (destination / "summary.json").exists():
        return
    gc.collect()
    torch.compiler.reset()
    if device == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
    seed_everything(seed + 1000)
    agent = new_agent(device)
    agent.load_checkpoint_state(copy.deepcopy(anchor["agent"]))
    agent.set_task(OLD)
    importance = torch.load(
        diagnostics_dir / "training_fisher.pt", map_location="cpu", weights_only=True
    )
    learner = ExpectedFisherEWC(agent, importance, ewc_lambda=config["ewc_lambda"])
    learner.set_task(NEW)
    probe = PolicyMemory.from_state_dict(anchor["probe"])
    history = []

    def record(steps, seconds, metrics):
        scores = {
            task: anchor[key][: config["eval_episodes"]]
            if steps == 0
            else evaluate(agent, task, config, eval_seed)
            for task, key, eval_seed in (
                (OLD, "old_scores", seed + 10000),
                (NEW, "new_scores", seed + 11000),
            )
        }
        history.append(
            {
                "steps": steps,
                "training_seconds": seconds,
                "scores": scores,
                "ppo_metrics": metrics,
                **policy_diagnostics(agent, probe, config["minibatch_size"]),
            }
        )
        write_json(destination / "history.json", {"history": history})
        print(json.dumps({"branch": "ewc_expected", **history[-1]}), flush=True)

    wall_start = time.perf_counter()
    record(0, 0.0, {})
    torch.set_rng_state(anchor["rng_cpu"])
    if device == "cuda":
        torch.cuda.set_rng_state_all(anchor["rng_cuda"])
    _, seconds = train_stage(learner, config, seed + 1000, config["new_steps"], record=record)
    state = agent.checkpoint_state()
    for kind in ("actors", "critics"):
        for name, value in anchor["agent"][kind][OLD].items():
            torch.testing.assert_close(state[kind][OLD][name].cpu(), value, rtol=0, atol=0)
    torch.save({"agent": state}, destination / "final.pt")
    final = history[-1]
    write_json(
        destination / "summary.json",
        {
            "branch": "ewc_expected",
            "training_seconds": seconds,
            "wall_seconds_including_evaluation": time.perf_counter() - wall_start,
            "new_auc_mean_reward": normalized_auc(history, NEW),
            "final_old_score": float(np.mean(final["scores"][OLD])),
            "final_new_score": float(np.mean(final["scores"][NEW])),
            "old_score_change": float(
                np.mean(final["scores"][OLD]) - np.mean(history[0]["scores"][OLD])
            ),
            "old_policy_kl": final["old_policy_kl"],
            "action_agreement": final["action_agreement"],
            "training_fisher_scale": diagnostic["training_fisher_scale"],
            "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated()
            if device == "cuda"
            else 0,
            "peak_cuda_reserved_bytes": torch.cuda.max_memory_reserved() if device == "cuda" else 0,
        },
    )
    write_json(output / "completion.json", {"status": "completed", "trained": True})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--diagnostics-only", action="store_true")
    args = parser.parse_args()
    run_study(
        json.loads(args.config.read_text()), args.seed, diagnostics_only=args.diagnostics_only
    )


if __name__ == "__main__":
    main()
