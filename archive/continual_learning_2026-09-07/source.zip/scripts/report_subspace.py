"""Audit and plot the completed paired GPM/SGP experiment without retraining."""

import hashlib
import json
from pathlib import Path

import matplotlib
import numpy as np
import torch

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from algorithms.subspace_projection import affine_layers, affine_matrix  # noqa: E402
from scripts.study_policy_replay import (  # noqa: E402
    NEW,
    OLD,
    ROOT,
    new_agent,
    normalized_auc,
    write_json,
)
from scripts.study_subspace import file_hash  # noqa: E402


def rollout_hashes(path: Path) -> dict:
    result, branch = {}, None
    for line in path.read_text().splitlines():
        if not line.startswith("{"):
            continue
        row = json.loads(line)
        branch = row.get("branch", branch)
        if "first_rollout_sha256" in row and branch is not None:
            result[branch] = row["first_rollout_sha256"]
    return result


def main() -> None:
    torch.set_num_threads(1)
    root = ROOT / "outputs/subspace_v1/seed-61001"
    source = ROOT / "outputs/policy_replay_v1/seed-61001"
    manifest = json.loads((root / "manifest.json").read_text())
    assert json.loads((root / "completion.json").read_text())["status"] == "completed"
    assert file_hash(source / "anchor.pt") == manifest["anchor_sha256"]
    for name, digest in manifest["source_sha256"].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
        assert file_hash(root / "source_snapshot" / name) == digest, name
    config = manifest["protocol"]
    assert not manifest["settings"].get("smoke", False)
    original = json.loads((source / "manifest.json").read_text())
    assert config == original["config"]
    hashes = rollout_hashes(ROOT / "logs/subspace_v1/subspace_seed61001.log")
    reference_hashes = rollout_hashes(ROOT / "logs/policy_replay_v1/policy_replay_seed61001.log")
    expected_hash = reference_hashes["finetune"]
    assert hashes == {"gpm": expected_hash, "sgp": expected_hash}

    anchor = torch.load(source / "anchor.pt", map_location="cpu", weights_only=True)
    basis = torch.load(root / "subspaces.pt", map_location="cpu", weights_only=True)
    baseline_agent = new_agent("cpu")
    baseline_agent.load_checkpoint_state(anchor["agent"])
    boundary_layers = affine_layers(baseline_agent.backbone)
    summaries, histories, audit = {}, {}, {}
    for method in ("finetune", "ewc", "policy_replay", "independent", "gpm", "sgp"):
        directory = (root if method in {"gpm", "sgp"} else source) / method
        summary = json.loads((directory / "summary.json").read_text())
        history = json.loads((directory / "history.json").read_text())["history"]
        assert [r["steps"] for r in history] == list(
            range(0, config["new_steps"] + 1, config["eval_interval"])
        )
        for row in history:
            assert all(len(row["scores"][t]) == config["eval_episodes"] for t in (OLD, NEW))
        assert history[0]["scores"][OLD] == anchor["old_scores"]
        assert np.isclose(summary["new_auc_mean_reward"], normalized_auc(history, NEW))
        assert np.isclose(summary["final_old_score"], np.mean(history[-1]["scores"][OLD]))
        assert np.isclose(summary["final_new_score"], np.mean(history[-1]["scores"][NEW]))
        summaries[method], histories[method] = summary, history
        if method not in {"gpm", "sgp"}:
            continue
        expected_steps = config["new_steps"] * config["update_epochs"] // config["minibatch_size"]
        assert summary["projection"]["optimizer_steps"] == expected_steps
        final = torch.load(directory / "final.pt", map_location="cpu", weights_only=True)["agent"]
        for kind in ("actors", "critics"):
            for name, tensor in anchor["agent"][kind][OLD].items():
                assert torch.equal(tensor, final[kind][OLD][name]), (method, kind, name)
        agent = new_agent("cpu")
        agent.load_checkpoint_state(final)
        cumulative = {}
        for name, layer in affine_layers(agent.backbone).items():
            u = basis[name]["basis"]
            torch.testing.assert_close(u.T @ u, torch.eye(u.shape[1]), atol=2e-6, rtol=2e-6)
            sigma = basis[name]["singular_values"]
            alpha = manifest["settings"]["alpha"]
            torch.testing.assert_close(
                basis[name]["importance"].double(),
                (alpha + 1) * sigma / (alpha * sigma + sigma[0]),
                atol=1e-7,
                rtol=1e-7,
            )
            delta = affine_matrix(layer).detach() - affine_matrix(boundary_layers[name]).detach()
            cumulative[name] = float((delta @ u).norm() / delta.norm())
            error = summary["projection"]["layers"][name]["projection_relative_error"]
            assert error < 0.001, (method, name, error)
        audit[method] = {
            "old_heads_bitwise_unchanged": True,
            "optimizer_steps": expected_steps,
            "cumulative_protected_displacement_fraction": cumulative,
            "per_step_projection": summary["projection"],
        }
    write_json(
        root / "audit.json",
        {"status": "passed", "first_rollout_hash": expected_hash, "methods": audit},
    )

    colors = dict(
        finetune="#777777",
        ewc="#c78823",
        policy_replay="#377eb8",
        independent="#222222",
        gpm="#8c55a4",
        sgp="#1b9e77",
    )
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), constrained_layout=True)
    for method, history in histories.items():
        x = np.array([r["steps"] for r in history]) / 1000
        for ax, task in zip(axes[:2], (OLD, NEW), strict=True):
            ax.plot(
                x,
                [np.mean(r["scores"][task]) for r in history],
                marker="o",
                markersize=3,
                label=method,
                color=colors[method],
            )
        axes[2].plot(
            x,
            [r["old_policy_kl"] for r in history],
            marker="o",
            markersize=3,
            label=method,
            color=colors[method],
        )
    for ax, title in zip(
        axes, ("Pong retention", "Breakout learning", "Old-policy probe KL"), strict=True
    ):
        ax.set_title(title)
        ax.set_xlabel("Breakout training transitions (thousands)")
        ax.grid(alpha=0.2)
    axes[0].set_ylabel("Mean raw episode return")
    axes[1].set_ylabel("Mean raw episode return")
    axes[2].set_yscale("symlog", linthresh=1e-5)
    axes[2].legend(fontsize=8)
    fig.suptitle("GPM / SGP paired comparison — seed 61001")
    for extension in ("png", "svg"):
        fig.savefig(root.parent / f"comparison.{extension}", dpi=180)
    plt.close(fig)

    lines = [
        "# GPM / SGP 单 seed 实验结果",
        "",
        "GPM、SGP 与原微调、EWC、回放分支共用同一 Pong 主干、Breakout head、Adam 状态和随机数起点；所有分支的新任务训练预算相同。独立网络参考的 Breakout 主干为随机初始化，不能当作相同表示起点。原四组结果保留，新增加 GPM、SGP 两组。原始 episode 数据、checkpoint、投影统计和源码快照保存在 outputs/subspace_v1/seed-61001。",
        "",
        "本次固定配置下，GPM 的两个任务终点和 Breakout AUC 均高于 SGP。相较原回放，两种投影方法的终点成绩都更高，但 Breakout AUC 都更低。因此，GPM 值得保留为兼顾任务终点的简单候选；当前结果不能认定它全面改善了稳定性与可塑性的取舍。",
        "",
        "SGP 在所测各层保留了更多更新能量，却没有在本次运行中取得更好的学习结果，旧策略 KL 也更高。这不支持继续为当前候选增加软投影机制，但不等于证明所有 SGP 配置均无效。比较中的约束强度、信息表示与旧 head 可塑性不同，不能把差异单独归因于某一个几何机制。",
        "",
        "| 方法 | Pong 最终 | Pong 变化 | Breakout 最终 | Breakout AUC / budget | 旧策略 KL | 更新秒数 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for method, s in summaries.items():
        lines.append(
            f"| {method} | {s['final_old_score']:.2f} | {s['old_score_change']:.2f} | {s['final_new_score']:.2f} | {s['new_auc_mean_reward']:.4f} | {s['old_policy_kl']:.6f} | {s['training_seconds']:.1f} |"
        )
    lines += [
        "",
        f"![comparison]({root.parent / 'comparison.png'})",
        "",
        "## 对原回放候选的逐项比较",
        "",
        "正数表示高于原回放分支；不同游戏不合并平均。以下是已暴露单 seed 的描述性结果。",
        "",
        "| 方法 | Pong 差值 | Breakout 终点差值 | Breakout AUC 差值 |",
        "|---|---:|---:|---:|",
    ]
    replay = summaries["policy_replay"]
    for method in ("gpm", "sgp"):
        s = summaries[method]
        lines.append(
            f"| {method} | {s['final_old_score'] - replay['final_old_score']:+.2f} | {s['final_new_score'] - replay['final_new_score']:+.2f} | {s['new_auc_mean_reward'] - replay['new_auc_mean_reward']:+.4f} |"
        )
    reference = summaries["independent"]
    gates = {}
    for method in ("gpm", "sgp"):
        s = summaries[method]
        checks = {
            "old_admission": float(np.mean(anchor["old_scores"])) >= config["anchor_min_score"],
            "retention": s["old_score_change"] >= -config["retention_margin"],
            "new_minimum": min(s["final_new_score"], reference["final_new_score"])
            >= config["new_min_score"],
            "new_endpoint_vs_reference": s["final_new_score"]
            >= reference["final_new_score"] - config["new_score_margin"],
            "new_auc_vs_reference": s["new_auc_mean_reward"]
            >= reference["new_auc_mean_reward"] - config["new_score_margin"],
        }
        gates[method] = {"passed": all(checks.values()), "checks": checks}
    write_json(root / "descriptive_gates.json", gates)
    lines += [
        "",
        "原实验描述性门槛的对照结果："
        + "；".join(f"{m} {'通过' if g['passed'] else '未通过'}" for m, g in gates.items())
        + "。逐项判定见 descriptive_gates.json；该门槛比较的是独立网络参考，不能替代对回放或微调的逐项比较。",
    ]
    lines += [
        "",
        "## 运行资源",
        "",
        "| 方法 | CUDA peak allocated MiB | CUDA peak reserved MiB |",
        "|---|---:|---:|",
    ]
    for method, s in summaries.items():
        lines.append(
            f"| {method} | {s['peak_cuda_allocated_bytes'] / 2**20:.2f} | {s['peak_cuda_reserved_bytes'] / 2**20:.2f} |"
        )
    construction = json.loads((root / "subspace_diagnostics.json").read_text())
    lines += [
        "",
        f"子空间构造耗时 {construction['construction_seconds']:.3f} 秒，两分支复用同一结果；已有旧状态采集开销沿用原实验并单独记录。",
        "更新耗时包含编译预热和投影诊断，不包含回合评估。显存是该实验进程测得的峰值，包含评估与临时张量；顺序运行的 SGP 阶段还持有前一分支的 checkpoint 状态，因此不能把该峰值直接解释为算法独立部署的最小显存。",
    ]
    lines += [
        "",
        "## 子空间与更新核对",
        "",
        "| 层 | 保护维数 / 输入维数（含偏置） | 捕获能量 | GPM 保留更新能量 | SGP 保留更新能量 |",
        "|---|---:|---:|---:|---:|",
    ]
    for name, entry in basis.items():
        retained = [
            summaries[m]["projection"]["layers"][name]["retained_update_energy_fraction"]
            for m in ("gpm", "sgp")
        ]
        lines.append(
            f"| {name} | {entry['rank']} / {entry['dimension']} | {entry['captured_energy_fraction']:.6f} | {retained[0]:.4f} | {retained[1]:.4f} |"
        )
    lines += [
        "",
        "投影核对直接测量 Adam 后实际更新；保留能量按整个训练过程累计。不同方法的轨迹与原始更新不同，能量比例不能单独当作学习能力的因果证据。硬投影的输出保护仅适用于估计子空间；截断方向和未覆盖状态仍可能漂移。",
        "",
        f"单份基与重要性向量占 {summaries['sgp']['projection_memory_bytes'] / 2**20:.3f} MiB。当前运行同时保留 CPU 归档与 GPU 工作副本，另有 Adam 状态、临时张量及诊断产物；此数字不是总主存或显存。",
        "",
        "共享偏置通过常数输入坐标纳入投影；卷积每个旧状态采样 16 个 patch。上述细节及短预算均属于本项目适配，不是原论文完整复现。只测试一个任务边界，未实现三任务及以上的 SGP 重要性累积。",
        "",
        "## 验证与来源",
        "",
        "audit.json 验证起点 checkpoint 哈希、源码与快照哈希、首批 rollout 相同、精确检查点、每次评估 episode 数、指标计算、旧 head 不变、基正交性及实际投影误差。完整测试 94 项通过，ruff 检查与格式检查通过；沙箱测试出现 NVML 警告，正式 GPU 运行正常。",
        "",
        "[实验协议](subspace_v1.md)；[GPM](https://arxiv.org/abs/2103.09762)；[SGP](https://arxiv.org/abs/2302.01386)。SGP 的 Adam-GP 处理见附录 E。",
    ]
    (ROOT / "experiments/subspace_v1_results.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"audit": "passed", "summaries": summaries}, indent=2))


if __name__ == "__main__":
    main()
