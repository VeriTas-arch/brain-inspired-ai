"""Single-seed GPM/SGP comparison from the frozen policy-replay Pong boundary."""

import argparse
import copy
import gc
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch

from algorithms.functional_replay import PolicyMemory
from algorithms.subspace_projection import AdamSubspaceProjection, build_input_subspaces
from algorithms.subspace_read import SubspaceReadPPOAgent
from scripts.study_policy_replay import (
    NEW,
    OLD,
    ROOT,
    evaluate,
    new_agent,
    normalized_auc,
    policy_diagnostics,
    source_hashes,
    train_stage,
    write_json,
)
from training import configure_ppo_runtime
from utils import seed_everything


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_study(settings: dict, seed: int) -> None:
    source = ROOT / settings["anchor_dir"]
    original = json.loads((source / "manifest.json").read_text())
    if seed != original["seed"]:
        raise ValueError("The seed must match the frozen anchor")
    config = original["config"].copy()
    if settings.get("smoke", False):
        config.update(new_steps=1024, eval_interval=1024, eval_episodes=1)
    configure_ppo_runtime(config["env_backend"])
    device = "cuda" if torch.cuda.is_available() else "cpu"
    output = ROOT / settings["output_dir"] / f"seed-{seed}"
    output.mkdir(parents=True, exist_ok=True)
    hashes = source_hashes()
    hashes["scripts/study_subspace.py"] = file_hash(Path(__file__))
    changed = [
        name
        for name, value in original["source_sha256"].items()
        if hashes.get(name) != value and name != "scripts/run_experiments.py"
    ]
    if changed:
        raise ValueError(f"Frozen PPO/evaluation sources changed: {changed}")
    manifest = {
        "settings": settings,
        "protocol": config,
        "seed": seed,
        "anchor_sha256": file_hash(source / "anchor.pt"),
        "source_sha256": hashes,
        "device": device,
        "torch": torch.__version__,
    }
    manifest_path = output / "manifest.json"
    if manifest_path.exists():
        if json.loads(manifest_path.read_text()) != manifest:
            raise ValueError("Study code/config changed; use a new output directory")
    else:
        write_json(manifest_path, manifest)
        for name in hashes:
            snapshot = output / "source_snapshot" / name
            snapshot.parent.mkdir(parents=True, exist_ok=True)
            snapshot.write_bytes((ROOT / name).read_bytes())

    anchor = torch.load(source / "anchor.pt", map_location="cpu", weights_only=True)
    subspace_path = output / "subspaces.pt"
    if not subspace_path.exists():
        agent = new_agent(device)
        agent.load_checkpoint_state(copy.deepcopy(anchor["agent"]))
        started = time.perf_counter()
        states = anchor["memory"]["tasks"][OLD][0]
        subspaces = build_input_subspaces(
            agent.backbone,
            states,
            threshold=settings["threshold"],
            alpha=settings["alpha"],
            seed=seed + 40000,
            batch_size=config["minibatch_size"],
            patches_per_observation=settings["patches_per_observation"],
        )
        torch.save(subspaces, subspace_path)
        diagnostics = {
            name: {
                key: value for key, value in entry.items() if not isinstance(value, torch.Tensor)
            }
            | {
                "importance_min": float(entry["importance"].min()),
                "importance_max": float(entry["importance"].max()),
                "orthonormal_error": float(
                    (entry["basis"].T @ entry["basis"] - torch.eye(entry["rank"])).abs().max()
                ),
            }
            for name, entry in subspaces.items()
        }
        write_json(
            output / "subspace_diagnostics.json",
            {"construction_seconds": time.perf_counter() - started, "layers": diagnostics},
        )
        print(json.dumps({"subspaces": diagnostics}), flush=True)
        del agent, subspaces
    subspaces = torch.load(subspace_path, map_location="cpu", weights_only=True)
    memory_bytes = sum(
        entry[key].numel() * entry[key].element_size()
        for entry in subspaces.values()
        for key in ("basis", "importance")
    )
    methods = settings.get("methods", ["gpm", "sgp"])
    for method in methods:
        destination = output / method
        destination.mkdir(exist_ok=True)
        if (destination / "summary.json").exists():
            continue
        gc.collect()
        torch.compiler.reset()
        if device == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
        seed_everything(seed + 1000)
        agent = (
            SubspaceReadPPOAgent(state_dim=4, device=device)
            if method == "gpm_read"
            else new_agent(device)
        )
        agent.load_checkpoint_state(copy.deepcopy(anchor["agent"]))
        if method == "gpm_read":
            states = anchor["memory"]["tasks"][OLD][0][: config["minibatch_size"]].to(device)
            with torch.no_grad():
                before = {task: agent.policy_logits(states, task).clone() for task in (OLD, NEW)}
            agent.add_read_scaling(subspaces["7"]["basis"], NEW)
            with torch.no_grad():
                for task in (OLD, NEW):
                    torch.testing.assert_close(
                        agent.policy_logits(states, task), before[task], rtol=0, atol=0
                    )
            write_json(
                destination / "initialization.json",
                {
                    "zero_scaling_logits_bitwise_equal": True,
                    "scaling_parameters": agent.backbone[7].scaling.numel(),
                },
            )
        projection = AdamSubspaceProjection(
            agent.optimizer,
            agent.backbone,
            subspaces,
            method="gpm" if method == "gpm_read" else method,
        )
        probe = PolicyMemory.from_state_dict(anchor["probe"])
        history = []

        def record(steps, seconds, metrics):
            scores = {
                task: anchor[key][: config["eval_episodes"]]
                if steps == 0
                else evaluate(agent, task, config, eval_seed)
                for task, key, eval_seed in (
                    (OLD, "old_scores", seed + 10000),
                    (NEW, "new_scores", seed + 11000),
                )
            }
            history.append(
                {
                    "steps": steps,
                    "training_seconds": seconds,
                    "scores": scores,
                    "reused_boundary_scores": steps == 0,
                    "ppo_metrics": metrics,
                    "projection": projection.metrics(),
                    **policy_diagnostics(agent, probe, config["minibatch_size"]),
                }
            )
            write_json(destination / "history.json", {"history": history})
            print(json.dumps({"branch": method, **history[-1]}), flush=True)

        wall_start = time.perf_counter()
        try:
            record(0, 0.0, {})
            torch.set_rng_state(anchor["rng_cpu"])
            if device == "cuda":
                torch.cuda.set_rng_state_all(anchor["rng_cuda"])
            _, seconds = train_stage(agent, config, seed + 1000, config["new_steps"], record=record)
            state = agent.checkpoint_state()
            # Old heads are not trained; only their shared input representation can drift.
            for kind in ("actors", "critics"):
                for name, value in anchor["agent"][kind][OLD].items():
                    torch.testing.assert_close(state[kind][OLD][name].cpu(), value, rtol=0, atol=0)
            torch.save({"agent": state, "method": method}, destination / "final.pt")
            final = history[-1]
            write_json(
                destination / "summary.json",
                {
                    "branch": method,
                    "training_seconds": seconds,
                    "wall_seconds_including_evaluation": time.perf_counter() - wall_start,
                    "new_auc_mean_reward": normalized_auc(history, NEW),
                    "final_old_score": float(np.mean(final["scores"][OLD])),
                    "final_new_score": float(np.mean(final["scores"][NEW])),
                    "old_score_change": float(
                        np.mean(final["scores"][OLD]) - np.mean(history[0]["scores"][OLD])
                    ),
                    "old_policy_kl": final["old_policy_kl"],
                    "action_agreement": final["action_agreement"],
                    "projection_memory_bytes": memory_bytes,
                    "projection": projection.metrics(),
                    "old_heads_unchanged": True,
                    "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated()
                    if device == "cuda"
                    else 0,
                    "peak_cuda_reserved_bytes": torch.cuda.max_memory_reserved()
                    if device == "cuda"
                    else 0,
                },
            )
        finally:
            projection.close()
        agent = projection = probe = record = None
    write_json(output / "completion.json", {"status": "completed", "methods": methods})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    run_study(json.loads(args.config.read_text()), args.seed)


if __name__ == "__main__":
    main()
