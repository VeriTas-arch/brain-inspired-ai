"""Audit the single-layer diagonal-read candidate against frozen GPM results."""

import json
from pathlib import Path

import matplotlib
import numpy as np
import torch

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from algorithms.subspace_projection import affine_layers, affine_matrix  # noqa: E402
from algorithms.subspace_read import SubspaceReadPPOAgent  # noqa: E402
from scripts.report_subspace import rollout_hashes  # noqa: E402
from scripts.study_policy_replay import (  # noqa: E402
    NEW,
    OLD,
    ROOT,
    new_agent,
    normalized_auc,
    write_json,
)
from scripts.study_subspace import file_hash  # noqa: E402


def main() -> None:
    torch.set_num_threads(1)
    root = ROOT / "outputs/subspace_read_v1/seed-61001"
    reference = ROOT / "outputs/subspace_v1/seed-61001"
    source = ROOT / "outputs/policy_replay_v1/seed-61001"
    manifest = json.loads((root / "manifest.json").read_text())
    config = manifest["protocol"]
    assert manifest["settings"] == json.loads(
        (ROOT / "experiments/subspace_read_v1.json").read_text()
    )
    assert not manifest["settings"].get("smoke", False)
    assert config == json.loads((source / "manifest.json").read_text())["config"]
    assert json.loads((root / "completion.json").read_text()) == {
        "status": "completed",
        "methods": ["gpm_read"],
    }
    assert file_hash(source / "anchor.pt") == manifest["anchor_sha256"]
    for name, digest in manifest["source_sha256"].items():
        assert file_hash(ROOT / name) == digest, name
        assert file_hash(root / "source_snapshot" / name) == digest, name
    prior_manifest = json.loads((reference / "manifest.json").read_text())
    for name, digest in prior_manifest["source_sha256"].items():
        assert file_hash(reference / "source_snapshot" / name) == digest, name
        if name not in {"scripts/run_experiments.py", "scripts/study_subspace.py"}:
            assert manifest["source_sha256"][name] == digest, name
    expected_hash = rollout_hashes(ROOT / "logs/subspace_v1/subspace_seed61001.log")["gpm"]
    assert rollout_hashes(ROOT / "logs/subspace_read_v1/subspace_seed61001.log") == {
        "gpm_read": expected_hash
    }
    anchor = torch.load(source / "anchor.pt", map_location="cpu", weights_only=True)
    basis = torch.load(root / "subspaces.pt", map_location="cpu", weights_only=True)
    old_basis = torch.load(reference / "subspaces.pt", map_location="cpu", weights_only=True)
    for name in basis:
        torch.testing.assert_close(basis[name], old_basis[name], rtol=0, atol=0)
    baseline = new_agent("cpu")
    baseline.load_checkpoint_state(anchor["agent"])
    final = torch.load(root / "gpm_read/final.pt", map_location="cpu", weights_only=True)["agent"]
    agent = SubspaceReadPPOAgent(state_dim=4, device="cpu")
    agent.load_checkpoint_state(final)
    assert agent.current_task == NEW and agent.backbone[7].enabled
    layer = agent.backbone[7]
    assert layer.scaling.numel() == 939 and layer.scaling.detach().norm() > 0
    assert int(agent.optimizer.state[layer.scaling]["step"]) == 65536
    assert torch.equal(layer.basis, basis["7"]["basis"])
    initial_dictionary = affine_matrix(baseline.backbone[7]).detach() @ layer.basis
    torch.testing.assert_close(layer.read_weights, initial_dictionary, atol=1e-6, rtol=1e-5)
    for kind in ("actors", "critics"):
        torch.testing.assert_close(final[kind][OLD], anchor["agent"][kind][OLD], rtol=0, atol=0)
    initialization = json.loads((root / "gpm_read/initialization.json").read_text())
    assert initialization == {"zero_scaling_logits_bitwise_equal": True, "scaling_parameters": 939}
    cumulative = {}
    for name, module in affine_layers(agent.backbone).items():
        delta = (
            affine_matrix(module).detach()
            - affine_matrix(affine_layers(baseline.backbone)[name]).detach()
        )
        cumulative[name] = float((delta @ basis[name]["basis"]).norm() / delta.norm())
        assert cumulative[name] < 0.001

    # Test the restored final model: modifying only the new-task scaling cannot
    # directly affect old logits, and it must affect the new task's forward path.
    states = anchor["probe"]["tasks"][OLD][0][:32]
    with torch.no_grad():
        old_logits = agent.policy_logits(states, OLD).clone()
        new_logits = agent.policy_logits(states, NEW).clone()
        saved = layer.scaling.clone()
        layer.scaling.add_(0.5)
        assert torch.equal(agent.policy_logits(states, OLD), old_logits)
        assert not torch.equal(agent.policy_logits(states, NEW), new_logits)
        layer.scaling.copy_(saved)
    summaries, histories = {}, {}
    for method, directory in (("gpm", reference / "gpm"), ("gpm_read", root / "gpm_read")):
        s = json.loads((directory / "summary.json").read_text())
        h = json.loads((directory / "history.json").read_text())["history"]
        assert [row["steps"] for row in h] == list(
            range(0, config["new_steps"] + 1, config["eval_interval"])
        )
        for row in h:
            assert all(len(row["scores"][task]) == config["eval_episodes"] for task in (OLD, NEW))
            assert (
                row["projection"]["optimizer_steps"]
                == row["steps"] * config["update_epochs"] // config["minibatch_size"]
            )
        assert h[0]["scores"] == {OLD: anchor["old_scores"], NEW: anchor["new_scores"]}
        assert np.isclose(s["new_auc_mean_reward"], normalized_auc(h, NEW))
        assert np.isclose(s["final_old_score"], np.mean(h[-1]["scores"][OLD]))
        assert np.isclose(s["final_new_score"], np.mean(h[-1]["scores"][NEW]))
        assert np.isclose(
            s["old_score_change"], s["final_old_score"] - np.mean(anchor["old_scores"])
        )
        assert s["projection"]["optimizer_steps"] == 65536
        assert all(
            v["projection_relative_error"] < 0.001 for v in s["projection"]["layers"].values()
        )
        summaries[method], histories[method] = s, h
    # Recompute the final functional diagnostic from the reloaded checkpoint.
    from algorithms.functional_replay import PolicyMemory
    from scripts.study_policy_replay import policy_diagnostics

    probe_metrics = policy_diagnostics(agent, PolicyMemory.from_state_dict(anchor["probe"]), 32)
    assert np.isclose(
        probe_metrics["old_policy_kl"], summaries["gpm_read"]["old_policy_kl"], atol=1e-6
    )
    assert probe_metrics["action_agreement"] == summaries["gpm_read"]["action_agreement"]
    keys = ("final_old_score", "final_new_score", "new_auc_mean_reward")
    differences = {k: summaries["gpm_read"][k] - summaries["gpm"][k] for k in keys}
    improved = all(v >= 0 for v in differences.values()) and any(
        differences[k] > 0 for k in keys[1:]
    )
    buffers = sum(t.numel() * t.element_size() for t in (layer.basis, layer.read_weights))
    audit = {
        "status": "passed",
        "same_first_rollout": expected_hash,
        "same_subspaces": True,
        "zero_initialization": initialization,
        "old_heads_bitwise_unchanged": True,
        "old_logits_isolated_from_scaling": True,
        "restored_policy_diagnostics": probe_metrics,
        "cumulative_protected_displacement_fraction": cumulative,
        "scaling_parameters": layer.scaling.numel(),
        "scaling_norm": float(layer.scaling.detach().norm()),
        "scaling_max_absolute": float(layer.scaling.detach().abs().max()),
        "scaling_optimizer_steps": 65536,
        "additional_buffer_bytes": buffers,
        "descriptive_complete_improvement": improved,
        "differences_from_gpm": differences,
    }
    write_json(root / "audit.json", audit)
    fig, axes = plt.subplots(1, 3, figsize=(13, 4), constrained_layout=True)
    for method, history in histories.items():
        x = np.array([row["steps"] for row in history]) / 1000
        for ax, task in zip(axes[:2], (OLD, NEW), strict=True):
            ax.plot(x, [np.mean(row["scores"][task]) for row in history], marker="o", label=method)
        axes[2].plot(x, [row["old_policy_kl"] for row in history], marker="o", label=method)
    for ax, title in zip(
        axes, ("Pong retention", "Breakout learning", "Old-policy probe KL"), strict=True
    ):
        ax.set_title(title)
        ax.set_xlabel("Breakout transitions (thousands)")
        ax.grid(alpha=0.2)
        ax.legend()
    axes[0].set_ylabel("Mean raw episode return")
    axes[1].set_ylabel("Mean raw episode return")
    fig.suptitle("GPM + task-specific diagonal subspace read — seed 61001")
    for extension in ("png", "svg"):
        fig.savefig(root.parent / f"comparison.{extension}", dpi=180)
    plt.close(fig)
    conclusion = (
        "达到预先规定的本实例完整改善条件。"
        if improved
        else "未达到预先规定的本实例完整改善条件；保留 GPM 为主候选，不扩大或调参重试这个变体。"
    )
    lines = [
        "# GPM + 单层对角子空间缩放实验结果",
        "",
        conclusion,
        "",
        "单 seed 61001，与已有 GPM 使用同一 Pong 起点、新任务 heads、已有 Adam 状态、随机数起点、子空间和训练评估预算。仅新增最后共享全连接层 ReLU 前的 939 维任务专属缩放，零初始化；使用原 PPO 损失。缩放只影响 Breakout，Pong 仍使用共享 GPM 路径。",
        "",
        "| 方法 | Pong 最终 | Breakout 最终 | Breakout AUC / budget | 旧策略 KL | 更新秒数 |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for method, s in summaries.items():
        lines.append(
            f"| {method} | {s['final_old_score']:.2f} | {s['final_new_score']:.2f} | {s['new_auc_mean_reward']:.4f} | {s['old_policy_kl']:.6f} | {s['training_seconds']:.1f} |"
        )
    lines += [
        "",
        "相对 GPM 的 Pong、Breakout 终点及 AUC 差值依次为："
        + "、".join(f"{differences[k]:+.4f}" for k in keys)
        + "。",
        "",
        f"![comparison]({root.parent / 'comparison.png'})",
        "",
        "这是已暴露单 seed 的描述性比较，不代表统计优越性。完整改善条件要求三个成绩指标均不下降，且至少一个 Breakout 指标提高。未把旧策略 KL、缩放非零或训练 loss 改善替代任务成绩。这里只检验两任务边界，不宣称长任务序列有效。",
        "",
        "## 实现和资源",
        "",
        f"新增可训练参数 939 个；当前实现额外缓存输入子空间和固定读取字典，共 {buffers / 2**20:.3f} MiB，另有缩放参数与其 Adam 状态。因而参数增量不等于全部存储增量。共享投影原有存储另计。",
        "",
        f"缩放向量最终范数 {audit['scaling_norm']:.6f}，最大绝对值 {audit['scaling_max_absolute']:.6f}；完成 65536 次 Adam 更新。",
        "",
        f"候选 CUDA peak allocated/reserved：{summaries['gpm_read']['peak_cuda_allocated_bytes'] / 2**20:.2f}/{summaries['gpm_read']['peak_cuda_reserved_bytes'] / 2**20:.2f} MiB；含评估总墙钟 {summaries['gpm_read']['wall_seconds_including_evaluation']:.1f} 秒。更新时间包含编译预热与诊断；未作为独立吞吐基准。",
        "",
        "## 审计",
        "",
        "audit.json 核验配置、源码快照与起点哈希、首批 rollout 相同、子空间逐位一致、准确 transition 和 optimizer-step 数、每任务评估回合数、原始分数重算、旧 heads 不变、固定读取字典、共享投影误差，以及最终 checkpoint 恢复后的任务隔离和策略 KL。",
        "",
        "方法依据是 [TRGP](https://arxiv.org/abs/2202.02931) 的 scaled weight projection；本候选只取单层对角缩放，不是完整 TRGP 或其 PPO 效果复现。[冻结协议](subspace_read_v1.md)。",
    ]
    (ROOT / "experiments/subspace_read_v1_results.md").write_text("\n".join(lines) + "\n")
    (root / "report_source.py").write_bytes(Path(__file__).read_bytes())
    (root / "report_source.sha256").write_text(file_hash(Path(__file__)) + "\n")
    print(json.dumps({"audit": audit, "summaries": summaries}, indent=2))


if __name__ == "__main__":
    main()
