"""Paired Pong -> Breakout qualification using the maintained PPO runtime."""

from __future__ import annotations

import argparse
import copy
import gc
import hashlib
import json
import platform
import subprocess
import time
from functools import partial
from pathlib import Path

import numpy as np
import torch

from algorithms import EWCWrapper, MultiHeadPPOAgent
from algorithms.functional_replay import PolicyMemory, policy_replay_loss
from environments import AtariEnv, make_vector_atari_env
from training import (
    PPOCollector,
    PPOLearner,
    configure_ppo_runtime,
    flatten_rollout_data,
    run_evaluation_episodes,
)
from utils import seed_everything

OLD, NEW = "Pong-v5", "Breakout-v5"
BRANCHES = ("finetune", "ewc", "policy_replay", "independent")
ROOT = Path(__file__).resolve().parents[1]


def write_json(path: Path, data: dict) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def source_hashes() -> dict[str, str]:
    paths = [ROOT / "scripts/study_policy_replay.py", ROOT / "scripts/run_experiments.py"]
    for directory in ("algorithms", "training", "environments", "utils"):
        paths.extend(sorted((ROOT / directory).glob("*.py")))
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def new_agent(device: str) -> MultiHeadPPOAgent:
    return MultiHeadPPOAgent(state_dim=4, device=device)


def evaluate(agent, task: str, config: dict, seed: int) -> list[float]:
    previous = agent.current_task
    agent.set_task(task)
    environment = AtariEnv(task, seed=seed, training=False)
    try:
        return run_evaluation_episodes(
            agent, environment, config["eval_episodes"], config["eval_max_steps"]
        )
    finally:
        environment.close()
        agent.set_task(previous)


def collect_policy_memory(agent, config: dict, seed: int, capacity: int) -> PolicyMemory:
    """Sample a fixed frozen-policy stream; no learning or saved PPO targets."""
    environment = make_vector_atari_env(
        OLD, config["num_envs"], backend=config["env_backend"], seed=seed, training=False
    )
    memory = PolicyMemory(capacity, seed=seed)
    devices = [agent.device.index or 0] if agent.device.type == "cuda" else []
    # Collection must not advance the RNG used by the subsequent PPO branch.
    with torch.random.fork_rng(devices=devices):
        torch.manual_seed(seed)
        collector = PPOCollector(
            environment, PPOLearner(agent), rollout_length=config["rollout_length"]
        )
        states, logits = [], []
        try:
            collected = 0
            while collected < config["memory_collection_steps"]:
                rollout = collector.collect(config["memory_collection_steps"] - collected)
                batch = flatten_rollout_data(rollout.data)["states"].clone()
                with torch.no_grad():
                    teacher = torch.cat(
                        [
                            agent.policy_logits(chunk.to(agent.device), OLD).cpu()
                            for chunk in batch.split(config["minibatch_size"])
                        ]
                    )
                states.append(batch)
                logits.append(teacher)
                collected += rollout.transition_count
            memory.add_task(OLD, torch.cat(states), torch.cat(logits))
        finally:
            environment.close()
    return memory


def policy_diagnostics(agent, probe: PolicyMemory, batch_size: int) -> dict:
    states, teacher = probe.tasks[OLD]
    kl, matches = 0.0, 0
    with torch.no_grad():
        for start in range(0, len(states), batch_size):
            target = teacher[start : start + batch_size].to(agent.device).log_softmax(-1)
            student = agent.policy_logits(
                states[start : start + batch_size].to(agent.device), OLD
            ).log_softmax(-1)
            kl += (target.exp() * (target - student)).sum().item()
            matches += (target.argmax(-1) == student.argmax(-1)).sum().item()
    return {"old_policy_kl": kl / len(states), "action_agreement": matches / len(states)}


def train_stage(agent, config: dict, seed: int, steps: int, *, regularizer=None, record=None):
    """Protocol scheduling only; collection, GAE and optimization stay in the runtime."""
    task = getattr(agent, "agent", agent).current_task
    environment = make_vector_atari_env(
        task, config["num_envs"], backend=config["env_backend"], seed=seed
    )
    learner = PPOLearner(
        agent,
        update_epochs=config["update_epochs"],
        minibatch_size=config["minibatch_size"],
        compile_policy=config["compile_ppo"],
        regularizer=regularizer,
    )
    collector = PPOCollector(environment, learner, rollout_length=config["rollout_length"])
    completed, training_seconds = 0, 0.0
    try:
        while completed < steps:
            remaining = min(
                steps - completed, config["eval_interval"] - completed % config["eval_interval"]
            )
            if agent.device.type == "cuda":
                torch.cuda.synchronize()
            started = time.perf_counter()
            rollout = collector.collect(remaining)
            if completed == 0:
                digest = hashlib.sha256()
                for field in ("states", "actions", "rewards", "dones"):
                    digest.update(rollout.data[field].cpu().contiguous().numpy().tobytes())
                print(
                    json.dumps({"task": task, "first_rollout_sha256": digest.hexdigest()}),
                    flush=True,
                )
            metrics = learner.update(rollout)
            if agent.device.type == "cuda":
                torch.cuda.synchronize()
            training_seconds += time.perf_counter() - started
            completed += rollout.transition_count
            if completed % config["eval_interval"] == 0 or completed == steps:
                print(
                    json.dumps(
                        {
                            "task": task,
                            "steps": completed,
                            "train_seconds": training_seconds,
                            **metrics,
                        }
                    ),
                    flush=True,
                )
                if record is not None:
                    record(completed, training_seconds, metrics)
        return flatten_rollout_data(rollout.data, clone=True), training_seconds
    finally:
        environment.close()


def normalized_auc(history: list[dict], task: str) -> float:
    steps = np.array([row["steps"] for row in history])
    means = np.array([np.mean(row["scores"][task]) for row in history])
    return float(np.trapezoid(means, steps) / (steps[-1] - steps[0]))


def run_study(config: dict, seed: int) -> None:
    configure_ppo_runtime(config["env_backend"])
    unit = config["num_envs"]
    for key in ("old_steps", "new_steps", "eval_interval", "memory_collection_steps"):
        if config[key] <= 0 or config[key] % unit:
            raise ValueError(f"{key} must be positive and divisible by num_envs")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    output = ROOT / config["output_dir"] / f"seed-{seed}"
    output.mkdir(parents=True, exist_ok=True)
    manifest = {"config": config, "seed": seed, "source_sha256": source_hashes()}
    manifest_path = output / "manifest.json"
    if manifest_path.exists():
        if json.loads(manifest_path.read_text()) != manifest:
            raise ValueError(
                "Existing study has different code or protocol; use a new output directory"
            )
    else:
        write_json(manifest_path, manifest)
        write_json(
            output / "environment.json",
            {
                "torch": torch.__version__,
                "python": platform.python_version(),
                "device": torch.cuda.get_device_name() if device == "cuda" else "cpu",
                "git_head": subprocess.check_output(
                    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
                ).strip(),
            },
        )
    anchor_path = output / "anchor.pt"
    if not anchor_path.exists():
        seed_everything(seed)
        agent = new_agent(device)
        environment = AtariEnv(OLD)
        agent.register_task(OLD, int(environment.action_space))
        environment.close()
        agent.set_task(OLD)
        last_rollout, seconds = train_stage(agent, config, seed, config["old_steps"])
        old_scores = evaluate(agent, OLD, config, seed + 10000)
        write_json(
            output / "anchor_scores.json", {"scores": old_scores, "training_seconds": seconds}
        )
        started = time.perf_counter()
        memory = collect_policy_memory(agent, config, seed + 20000, config["memory_capacity"])
        memory_seconds = time.perf_counter() - started
        probe = collect_policy_memory(agent, config, seed + 30000, config["probe_capacity"])
        seed_everything(seed + 1000)
        environment = AtariEnv(NEW)
        agent.register_task(NEW, int(environment.action_space))
        environment.close()
        # The same new heads, old backbone and Adam history feed all shared branches.
        agent.set_task(NEW)
        new_scores = evaluate(agent, NEW, config, seed + 11000)
        torch.save(
            {
                "agent": agent.checkpoint_state(),
                "last_rollout": last_rollout,
                "memory": memory.state_dict(),
                "probe": probe.state_dict(),
                "old_scores": old_scores,
                "new_scores": new_scores,
                "memory_collection_seconds": memory_seconds,
                "rng_cpu": torch.get_rng_state(),
                "rng_cuda": torch.cuda.get_rng_state_all() if device == "cuda" else [],
            },
            anchor_path,
        )
        del agent, memory, probe, last_rollout
    anchor = torch.load(anchor_path, map_location="cpu", weights_only=True)
    if np.mean(anchor["old_scores"]) < config["anchor_min_score"]:
        write_json(
            output / "qualification.json",
            {
                "status": "anchor_failed",
                "mean_old_score": float(np.mean(anchor["old_scores"])),
                "reason": "Fixed-budget old policy did not meet the preregistered learned-task gate; no retention verdict.",
            },
        )
        return
    for branch in BRANCHES:
        destination = output / branch
        destination.mkdir(exist_ok=True)
        if (destination / "summary.json").exists():
            continue
        gc.collect()
        torch.compiler.reset()
        if device == "cuda":
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
        wall_start = time.perf_counter()
        seed_everything(seed + 1000)
        agent = new_agent(device)
        agent.load_checkpoint_state(copy.deepcopy(anchor["agent"]))
        old_agent = agent
        train_agent, regularizer = agent, None
        memory = None
        if branch == "independent":
            agent = new_agent(device)
            agent.register_task(NEW, anchor["agent"]["task_action_dims"][NEW])
            agent.actors[NEW].load_state_dict(anchor["agent"]["actors"][NEW])
            agent.critics[NEW].load_state_dict(anchor["agent"]["critics"][NEW])
            agent.set_task(NEW)
            train_agent = agent
            for module in (old_agent.backbone, old_agent.actors, old_agent.critics):
                module.requires_grad_(False)
        elif branch == "ewc":
            agent.set_task(OLD)
            train_agent = EWCWrapper(agent, ewc_lambda=config["ewc_lambda"])
            train_agent.consolidate_weights(anchor["last_rollout"])
            train_agent.set_task(NEW)
        elif branch == "policy_replay":
            memory = PolicyMemory.from_state_dict(anchor["memory"])
            regularizer = partial(
                policy_replay_loss,
                agent,
                memory,
                batch_size=config["minibatch_size"],
                weight=config["distillation_weight"],
            )
        probe = PolicyMemory.from_state_dict(anchor["probe"])
        history = []

        def record(steps, training_seconds, metrics):
            reuse_old = steps == 0 or branch == "independent"
            reuse_new = steps == 0 and branch != "independent"
            scores = {
                OLD: anchor["old_scores"]
                if reuse_old
                else evaluate(old_agent, OLD, config, seed + 10000),
                NEW: anchor["new_scores"]
                if reuse_new
                else evaluate(agent, NEW, config, seed + 11000),
            }
            history.append(
                {
                    "steps": steps,
                    "training_seconds": training_seconds,
                    "scores": scores,
                    "reused_boundary_scores": {OLD: reuse_old, NEW: reuse_new},
                    "ppo_metrics": metrics,
                    **policy_diagnostics(old_agent, probe, config["minibatch_size"]),
                }
            )
            write_json(destination / "history.json", {"history": history})
            print(json.dumps({"branch": branch, **history[-1]}), flush=True)

        record(0, 0.0, {})
        # Setup, evaluation and regularizer construction cannot shift branch sampling.
        torch.set_rng_state(anchor["rng_cpu"])
        if device == "cuda":
            torch.cuda.set_rng_state_all(anchor["rng_cuda"])
        _, seconds = train_stage(
            train_agent,
            config,
            seed + 1000,
            config["new_steps"],
            regularizer=regularizer,
            record=record,
        )
        torch.save(
            {"agent": agent.checkpoint_state(), "memory": memory.state_dict() if memory else None},
            destination / "final.pt",
        )
        final = history[-1]
        summary = {
            "branch": branch,
            "training_seconds": seconds,
            "wall_seconds_including_evaluation_and_setup": time.perf_counter() - wall_start,
            "new_auc_mean_reward": normalized_auc(history, NEW),
            "final_old_score": float(np.mean(final["scores"][OLD])),
            "final_new_score": float(np.mean(final["scores"][NEW])),
            "old_score_change": float(
                np.mean(final["scores"][OLD]) - np.mean(anchor["old_scores"])
            ),
            "old_policy_kl": final["old_policy_kl"],
            "action_agreement": final["action_agreement"],
            "memory_tensor_bytes": memory.tensor_bytes if memory else 0,
            "memory_collection_steps": config["memory_collection_steps"] if memory else 0,
            "memory_collection_seconds": anchor["memory_collection_seconds"] if memory else 0,
            "peak_cuda_allocated_bytes": torch.cuda.max_memory_allocated()
            if device == "cuda"
            else 0,
            "peak_cuda_reserved_bytes": torch.cuda.max_memory_reserved() if device == "cuda" else 0,
            "reference_old_checkpoint": "../anchor.pt" if branch == "independent" else None,
        }
        write_json(destination / "summary.json", summary)
        agent = train_agent = old_agent = memory = regularizer = probe = record = None
    summaries = {b: json.loads((output / b / "summary.json").read_text()) for b in BRANCHES}
    replay, reference = summaries["policy_replay"], summaries["independent"]
    passed = (
        replay["old_score_change"] >= -config["retention_margin"]
        and replay["final_new_score"] >= config["new_min_score"]
        and reference["final_new_score"] >= config["new_min_score"]
        and replay["final_new_score"] >= reference["final_new_score"] - config["new_score_margin"]
        and replay["new_auc_mean_reward"]
        >= reference["new_auc_mean_reward"] - config["new_score_margin"]
    )
    write_json(
        output / "qualification.json",
        {
            "status": "candidate_passed" if passed else "candidate_failed",
            "summaries": summaries,
            "interpretation": "A budget-specific qualification, not evidence of intrinsic capacity conflict or a general continual-learning solution.",
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    args = parser.parse_args()
    run_study(json.loads(args.config.read_text()), args.seed)


if __name__ == "__main__":
    main()
