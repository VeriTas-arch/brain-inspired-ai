"""Run the repository's standard training and evaluation matrices."""

from __future__ import annotations

import argparse
import os
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from training import DEFAULT_MAX_EPISODE_STEPS

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_GAMES = {
    "single": ("Pong-v5", "Breakout-v5"),
    "continual": ("Pong-v5", "Breakout-v5", "SpaceInvaders-v5"),
    "multitask": ("Pong-v5", "Breakout-v5", "SpaceInvaders-v5"),
}
DEFAULT_TRAINING_STEPS = {
    "single": 500_000,
    "continual": 500_000,
    "multitask": 50_000,
}


@dataclass(frozen=True)
class Job:
    """One child Python process in an experiment matrix."""

    name: str
    arguments: tuple[str, ...]
    log_name: str
    capture_output: bool

    @property
    def command(self) -> tuple[str, ...]:
        return (sys.executable, *self.arguments)


def _game_slug(game: str) -> str:
    return game.removesuffix("-v5").replace("/", "_").lower()


def build_policy_replay_jobs(config: Path, seeds: Sequence[int]) -> list[Job]:
    """One paired four-branch study per seed, governed by a frozen protocol file."""
    return [
        Job(
            f"policy replay study seed {seed}",
            ("scripts/study_policy_replay.py", "--config", str(config), "--seed", str(seed)),
            f"policy_replay_seed{seed}.log",
            True,
        )
        for seed in seeds
    ]


def build_subspace_jobs(config: Path, seeds: Sequence[int]) -> list[Job]:
    """Compare GPM and SGP from an existing paired-study boundary."""
    return [
        Job(
            f"subspace study seed {seed}",
            ("-m", "scripts.study_subspace", "--config", str(config), "--seed", str(seed)),
            f"subspace_seed{seed}.log",
            True,
        )
        for seed in seeds
    ]


def build_expected_fisher_jobs(
    config: Path, seeds: Sequence[int], *, diagnostics_only: bool
) -> list[Job]:
    """Boundary Fisher diagnostics and at most one admitted EWC branch."""
    return [
        Job(
            f"expected Fisher study seed {seed}",
            (
                "-m",
                "scripts.study_expected_fisher",
                "--config",
                str(config),
                "--seed",
                str(seed),
                *(("--diagnostics-only",) if diagnostics_only else ()),
            ),
            f"fisher_{'diagnostics' if diagnostics_only else 'train'}_seed{seed}.log",
            True,
        )
        for seed in seeds
    ]


def _ewc_variants(mode: str) -> tuple[bool, ...]:
    if mode == "both":
        return (False, True)
    return (mode == "on",)


def build_jobs(
    phase: str,
    suite: str,
    *,
    games: Sequence[str],
    algorithms: Sequence[str],
    steps: int | None = None,
    episodes: int = 10,
    max_steps: int = DEFAULT_MAX_EPISODE_STEPS,
    ewc_lambda: float = 0.4,
    ewc_mode: str = "both",
    seed: int = 0,
    num_envs: int = 1,
    env_backend: str = "sync",
    compile_ppo: bool = False,
) -> list[Job]:
    """Build the process matrix formerly encoded in the shell scripts."""
    if episodes <= 0:
        raise ValueError("episodes must be positive")
    if max_steps <= 0:
        raise ValueError("max_steps must be positive")
    if not 0 <= seed < 2**32:
        raise ValueError("seed must be between 0 and 2**32 - 1")
    if num_envs <= 0:
        raise ValueError("num_envs must be positive")
    if env_backend not in {"sync", "async"}:
        raise ValueError("env_backend must be 'sync' or 'async'")
    if num_envs > 1 and (phase != "train" or suite == "multitask" or tuple(algorithms) != ("ppo",)):
        raise ValueError("num_envs greater than one supports PPO single/continual training only")
    if (env_backend != "sync" or compile_ppo) and (
        phase != "train" or suite == "multitask" or tuple(algorithms) != ("ppo",)
    ):
        raise ValueError("optimized PPO runtime options support single/continual PPO training only")
    if phase == "train":
        training_steps = steps if steps is not None else DEFAULT_TRAINING_STEPS[suite]
        if training_steps <= 0:
            raise ValueError("steps must be positive")
        return _build_training_jobs(
            suite,
            games,
            algorithms,
            training_steps,
            episodes,
            max_steps,
            ewc_lambda,
            ewc_mode,
            seed,
            num_envs,
            env_backend,
            compile_ppo,
        )

    return _build_evaluation_jobs(
        suite, games, algorithms, episodes, max_steps, ewc_lambda, ewc_mode, seed
    )


def _build_training_jobs(
    suite: str,
    games: Sequence[str],
    algorithms: Sequence[str],
    steps: int,
    eval_episodes: int,
    eval_max_steps: int,
    ewc_lambda: float,
    ewc_mode: str,
    seed: int,
    num_envs: int,
    env_backend: str,
    compile_ppo: bool,
) -> list[Job]:
    jobs = []
    if suite == "single":
        for game in games:
            for algorithm in algorithms:
                name = f"single {game} {algorithm}"
                arguments = [
                    "scripts/train_single.py",
                    "--seed",
                    str(seed),
                    "--game",
                    game,
                    "--algorithm",
                    algorithm,
                    "--steps",
                    str(steps),
                ]
                if num_envs > 1:
                    arguments.extend(("--num-envs", str(num_envs)))
                if algorithm == "ppo" and env_backend != "sync":
                    arguments.extend(("--env-backend", env_backend))
                if algorithm == "ppo" and compile_ppo:
                    arguments.append("--compile-ppo")
                jobs.append(
                    Job(
                        name,
                        tuple(arguments),
                        f"{_game_slug(game)}_{algorithm}_seed{seed}.log",
                        True,
                    )
                )
    elif suite == "continual":
        for algorithm in algorithms:
            for use_ewc in _ewc_variants(ewc_mode):
                arguments = [
                    "scripts/train_continual.py",
                    "--seed",
                    str(seed),
                    "--games",
                    *games,
                    "--algorithm",
                    algorithm,
                    "--steps-per-game",
                    str(steps),
                    "--eval-episodes",
                    str(eval_episodes),
                    "--eval-max-steps",
                    str(eval_max_steps),
                ]
                variant = "ewc" if use_ewc else "no_ewc"
                if use_ewc:
                    arguments.extend(("--use-ewc", "--ewc-lambda", str(ewc_lambda)))
                if num_envs > 1:
                    arguments.extend(("--num-envs", str(num_envs)))
                if algorithm == "ppo" and env_backend != "sync":
                    arguments.extend(("--env-backend", env_backend))
                if algorithm == "ppo" and compile_ppo:
                    arguments.append("--compile-ppo")
                jobs.append(
                    Job(
                        f"continual {algorithm} {variant}",
                        tuple(arguments),
                        f"continual_{algorithm}_{variant}_seed{seed}.log",
                        True,
                    )
                )
    else:
        for algorithm in algorithms:
            jobs.append(
                Job(
                    f"multitask {algorithm}",
                    (
                        "scripts/train_multitask.py",
                        "--seed",
                        str(seed),
                        "--games",
                        *games,
                        "--algorithm",
                        algorithm,
                        "--steps",
                        str(steps),
                    ),
                    f"multitask_{algorithm}_seed{seed}.log",
                    True,
                )
            )
    return jobs


def _build_evaluation_jobs(
    suite: str,
    games: Sequence[str],
    algorithms: Sequence[str],
    episodes: int,
    max_steps: int,
    ewc_lambda: float,
    ewc_mode: str,
    seed: int,
) -> list[Job]:
    jobs = []
    if suite == "single":
        for game in games:
            for algorithm in algorithms:
                run_name = f"{game}_{algorithm}"
                jobs.append(
                    Job(
                        f"evaluate single {game} {algorithm}",
                        (
                            "scripts/evaluate.py",
                            "--seed",
                            str(seed),
                            "--mode",
                            "single",
                            "--model",
                            f"checkpoints/single/{run_name}/seed-{seed}.pt",
                            "--algorithm",
                            algorithm,
                            "--game",
                            game,
                            "--episodes",
                            str(episodes),
                            "--max-steps",
                            str(max_steps),
                            "--json-out",
                            f"outputs/single/{run_name}/seed-{seed}/eval/metrics.json",
                        ),
                        f"evaluate_{_game_slug(game)}_{algorithm}_seed{seed}.log",
                        False,
                    )
                )
    elif suite == "continual":
        for algorithm in algorithms:
            for use_ewc in _ewc_variants(ewc_mode):
                variant = f"{algorithm}_ewc{use_ewc}"
                arguments = [
                    "scripts/evaluate.py",
                    "--seed",
                    str(seed),
                    "--mode",
                    "continual",
                    "--model",
                    f"checkpoints/continual/{variant}/seed-{seed}.pt",
                    "--algorithm",
                    algorithm,
                    "--games",
                    *games,
                    "--episodes",
                    str(episodes),
                    "--max-steps",
                    str(max_steps),
                    "--json-out",
                    f"outputs/continual/{variant}/seed-{seed}/eval/metrics.json",
                ]
                if use_ewc:
                    arguments.extend(("--ewc", "--ewc-lambda", str(ewc_lambda)))
                jobs.append(
                    Job(
                        f"evaluate continual {algorithm} ewc={use_ewc}",
                        tuple(arguments),
                        f"evaluate_continual_{variant}_seed{seed}.log",
                        False,
                    )
                )
    else:
        for algorithm in algorithms:
            jobs.append(
                Job(
                    f"evaluate multitask {algorithm}",
                    (
                        "scripts/evaluate.py",
                        "--seed",
                        str(seed),
                        "--mode",
                        "multitask",
                        "--model",
                        f"checkpoints/multitask/{algorithm}/seed-{seed}.pt",
                        "--algorithm",
                        algorithm,
                        "--games",
                        *games,
                        "--episodes",
                        str(episodes),
                        "--max-steps",
                        str(max_steps),
                        "--json-out",
                        f"outputs/multitask/{algorithm}/seed-{seed}/eval/metrics.json",
                    ),
                    f"evaluate_multitask_{algorithm}_seed{seed}.log",
                    False,
                )
            )
    return jobs


def _cuda_device_count(device: str) -> int:
    if device == "cpu":
        return 0

    import torch

    count = torch.cuda.device_count() if torch.cuda.is_available() else 0
    if device == "cuda" and count == 0:
        raise RuntimeError("--device cuda was requested, but PyTorch found no CUDA devices")
    return count


def _job_environment(device_count: int, job_index: int, parallel: bool) -> dict[str, str]:
    environment = os.environ.copy()
    if device_count == 0:
        environment["CUDA_VISIBLE_DEVICES"] = ""
    else:
        environment["CUDA_VISIBLE_DEVICES"] = str(job_index % device_count if parallel else 0)
    return environment


def _print_job(job: Job, index: int, total: int, device: str) -> None:
    print(f"[{index}/{total}] {job.name} ({device})")
    print(f"  {shlex.join(job.command)}")


def run_jobs(
    jobs: Sequence[Job],
    *,
    device: str,
    parallel: bool,
    log_dir: Path,
) -> None:
    """Execute jobs sequentially or concurrently and fail on any child error."""
    device_count = _cuda_device_count(device)
    if not log_dir.is_absolute():
        log_dir = PROJECT_ROOT / log_dir
    log_dir.mkdir(parents=True, exist_ok=True)

    if not parallel:
        for index, job in enumerate(jobs):
            environment = _job_environment(device_count, index, parallel=False)
            device_label = "cpu" if device_count == 0 else "cuda:0"
            _print_job(job, index + 1, len(jobs), device_label)
            if job.capture_output:
                log_path = log_dir / job.log_name
                with log_path.open("w", encoding="utf-8") as log_file:
                    result = subprocess.run(
                        job.command,
                        cwd=PROJECT_ROOT,
                        env=environment,
                        stdout=log_file,
                        stderr=subprocess.STDOUT,
                        check=False,
                    )
            else:
                result = subprocess.run(
                    job.command,
                    cwd=PROJECT_ROOT,
                    env=environment,
                    check=False,
                )
            if result.returncode != 0:
                raise RuntimeError(f"Job failed with exit code {result.returncode}: {job.name}")
        return

    running = []
    try:
        for index, job in enumerate(jobs):
            environment = _job_environment(device_count, index, parallel=True)
            gpu_index = index % device_count if device_count else None
            device_label = "cpu" if gpu_index is None else f"cuda:{gpu_index}"
            _print_job(job, index + 1, len(jobs), device_label)
            log_path = log_dir / job.log_name
            log_file = log_path.open("w", encoding="utf-8")
            process = subprocess.Popen(
                job.command,
                cwd=PROJECT_ROOT,
                env=environment,
                stdout=log_file,
                stderr=subprocess.STDOUT,
            )
            running.append((job, process, log_file))

        failures = []
        for job, process, _ in running:
            return_code = process.wait()
            if return_code != 0:
                failures.append(f"{job.name} (exit {return_code})")
        if failures:
            raise RuntimeError("Failed jobs: " + ", ".join(failures))
    except KeyboardInterrupt:
        for _, process, _ in running:
            process.terminate()
        for _, process, _ in running:
            process.wait()
        raise
    finally:
        for _, _, log_file in running:
            log_file.close()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("train", "evaluate"))
    parser.add_argument(
        "suite",
        choices=(
            "single",
            "continual",
            "multitask",
            "policy-replay",
            "subspace",
            "expected-fisher",
        ),
    )
    parser.add_argument("--study-config", type=Path, help="Frozen policy-replay study protocol")
    parser.add_argument(
        "--diagnostics-only",
        action="store_true",
        help="Run only the expected-Fisher admission diagnostics",
    )
    parser.add_argument("--games", nargs="+", help="Override the suite's default games")
    parser.add_argument(
        "--algorithms",
        nargs="+",
        choices=("dqn", "ppo"),
        default=("dqn", "ppo"),
    )
    parser.add_argument("--steps", type=int, help="Training steps or steps per game")
    parser.add_argument("--episodes", type=int, default=10, help="Evaluation episodes per game")
    parser.add_argument(
        "--max-steps",
        type=int,
        default=DEFAULT_MAX_EPISODE_STEPS,
        help="Maximum agent steps per episode; incomplete episodes are rejected",
    )
    seed_group = parser.add_mutually_exclusive_group()
    seed_group.add_argument("--seed", type=int, default=0)
    seed_group.add_argument("--seeds", type=int, nargs="+", help="Expand the matrix over seeds")
    parser.add_argument("--ewc-lambda", type=float, default=0.4)
    parser.add_argument(
        "--ewc-mode",
        choices=("both", "on", "off"),
        default="both",
        help="Continual suite variants to run",
    )
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument(
        "--num-envs",
        type=int,
        default=1,
        help="Environments used for batched PPO policy inference",
    )
    parser.add_argument(
        "--env-backend",
        choices=("sync", "async"),
        default="sync",
        help="PPO environment execution backend",
    )
    parser.add_argument(
        "--compile-ppo",
        action="store_true",
        help="Compile PPO rollout and learner policy evaluation",
    )
    parser.add_argument("--parallel", action="store_true", help="Run all jobs concurrently")
    parser.add_argument("--log-dir", type=Path, default=Path("logs"))
    parser.add_argument("--dry-run", action="store_true", help="Print commands without running")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    """Parse the experiment matrix and launch its Python child processes."""
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        seeds = args.seeds or (args.seed,)
        if args.suite in {"policy-replay", "subspace", "expected-fisher"}:
            if args.phase != "train" or args.study_config is None:
                raise ValueError(f"{args.suite} requires train and --study-config")
            if args.suite == "expected-fisher":
                jobs = build_expected_fisher_jobs(
                    args.study_config, seeds, diagnostics_only=args.diagnostics_only
                )
            else:
                builder = (
                    build_policy_replay_jobs
                    if args.suite == "policy-replay"
                    else build_subspace_jobs
                )
                jobs = builder(args.study_config, seeds)
            if args.dry_run:
                for index, job in enumerate(jobs, start=1):
                    _print_job(job, index, len(jobs), args.device)
            else:
                run_jobs(jobs, device=args.device, parallel=args.parallel, log_dir=args.log_dir)
            return
        games = args.games or DEFAULT_GAMES[args.suite]
        jobs = []
        for seed in seeds:
            jobs.extend(
                build_jobs(
                    args.phase,
                    args.suite,
                    games=games,
                    algorithms=args.algorithms,
                    steps=args.steps,
                    episodes=args.episodes,
                    max_steps=args.max_steps,
                    ewc_lambda=args.ewc_lambda,
                    ewc_mode=args.ewc_mode,
                    seed=seed,
                    num_envs=args.num_envs,
                    env_backend=args.env_backend,
                    compile_ppo=args.compile_ppo,
                )
            )
        if args.dry_run:
            for index, job in enumerate(jobs, start=1):
                _print_job(job, index, len(jobs), args.device)
            return
        run_jobs(jobs, device=args.device, parallel=args.parallel, log_dir=args.log_dir)
    except (RuntimeError, ValueError) as error:
        parser.exit(1, f"error: {error}\n")


if __name__ == "__main__":
    main()
