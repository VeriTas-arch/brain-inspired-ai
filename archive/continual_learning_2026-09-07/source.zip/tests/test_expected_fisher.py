"""Test the analytic action expectation and reuse of the unchanged EWC penalty."""

import copy

import torch
import torch.nn as nn

from algorithms.expected_fisher import ExpectedFisherEWC, estimate_policy_fisher
from tests.test_functional_replay import tiny_agent


def test_expected_fisher_matches_categorical_linear_analytic_diagonal():
    torch.manual_seed(23)
    model = nn.Linear(2, 3, dtype=torch.float64)
    states = torch.tensor([[255, 0], [0, 255], [255, 255], [64, 128]], dtype=torch.uint8)
    saved = copy.deepcopy(model.state_dict())
    rng = torch.get_rng_state().clone()
    estimates = estimate_policy_fisher(model, nn.Identity(), states, batch_size=2, seed=7)
    p = model(states.double() / 255).softmax(-1).detach()
    variance = p * (1 - p)
    expected_weight = (variance[:, :, None] * (states.double()[:, None, :] / 255).square()).mean(0)
    torch.testing.assert_close(
        estimates["expected"]["weight"].double(), expected_weight, atol=1e-8, rtol=1e-6
    )
    torch.testing.assert_close(
        estimates["expected"]["bias"].double(), variance.mean(0), atol=1e-8, rtol=1e-6
    )
    torch.testing.assert_close(model.state_dict(), saved, rtol=0, atol=0)
    assert all(p.grad is None for p in model.parameters())
    assert torch.equal(rng, torch.get_rng_state())
    other = estimate_policy_fisher(model, nn.Identity(), states, batch_size=1, seed=7)
    torch.testing.assert_close(other["expected"], estimates["expected"], atol=1e-8, rtol=1e-6)


def test_expected_fisher_includes_low_probability_actions_at_confident_policy():
    model = nn.Linear(1, 2, bias=False)
    with torch.no_grad():
        model.weight.copy_(torch.tensor([[4.0], [-4.0]]))
    states = torch.full((4, 1), 255, dtype=torch.uint8)
    estimates = estimate_policy_fisher(model, nn.Identity(), states, seed=1)
    # A sampled likely action can have a tiny squared score; the expectation
    # must also retain the rare action's large score contribution.
    assert estimates["expected"]["weight"].min() > 1e-4
    assert estimates["expected"]["weight"].sum() > 100 * estimates["sampled"]["weight"].sum()


def test_precomputed_fisher_uses_original_quadratic_and_leaves_adam_unchanged():
    agent = tiny_agent()
    importance = {k: torch.ones_like(p) for k, p in agent.backbone.named_parameters()}
    before = copy.deepcopy(agent.optimizer.state_dict())
    wrapper = ExpectedFisherEWC(agent, importance, ewc_lambda=0.4)
    torch.testing.assert_close(agent.optimizer.state_dict(), before)
    assert wrapper.compute_ewc_loss() == 0
    means = {k: p.detach().clone() for k, p in agent.backbone.named_parameters()}
    with torch.no_grad():
        next(agent.backbone.parameters()).add_(0.05)
    expected = 0.2 * sum(
        (p - means[k]).square().sum() for k, p in agent.backbone.named_parameters()
    )
    torch.testing.assert_close(wrapper.compute_ewc_loss(), expected)
    wrapper.configure_regularizer(compile_regularizer=False)
    torch.testing.assert_close(wrapper._runtime_regularizer(), expected)
    assert all(k.startswith("backbone.") for k in wrapper.aggregated_fisher)
