"""Verify task isolation, optimizer participation, and checkpoint restoration."""

import copy

import torch
import torch.nn as nn

from algorithms.subspace_projection import AdamSubspaceProjection, affine_layers, affine_matrix
from algorithms.subspace_read import SubspaceReadLinear, SubspaceReadPPOAgent
from training.ppo_runtime import CollectedRollout, PPOLearner


def test_diagonal_read_matches_affine_formula_without_reinitializing_weights():
    layer = nn.Linear(3, 2, dtype=torch.float64)
    basis = torch.linalg.qr(torch.randn(4, 2, dtype=torch.float64)).Q
    x = torch.randn(5, 3, dtype=torch.float64)
    rng = torch.get_rng_state().clone()
    adapted = SubspaceReadLinear(layer, basis)
    assert adapted.weight is layer.weight and adapted.bias is layer.bias
    assert torch.equal(rng, torch.get_rng_state())
    adapted.enabled = True
    torch.testing.assert_close(adapted(x), layer(x), rtol=0, atol=0)
    with torch.no_grad():
        adapted.scaling.copy_(torch.tensor([0.8, -0.3]))
    augmented = torch.cat((x, torch.ones(5, 1, dtype=x.dtype)), dim=1)
    weight = affine_matrix(layer)
    effective = weight + weight @ basis @ torch.diag(adapted.scaling) @ basis.T
    torch.testing.assert_close(adapted(x), augmented @ effective.T)
    adapted(x).square().sum().backward()
    assert adapted.scaling.grad.norm() > 0
    assert not adapted.basis.requires_grad and not adapted.read_weights.requires_grad
    adapted.enabled = False
    torch.testing.assert_close(adapted(x), layer(x), rtol=0, atol=0)


def test_ppo_scaling_trains_with_gpm_and_restores_task_routing_and_adam():
    torch.set_num_threads(1)
    torch.manual_seed(81)
    agent = SubspaceReadPPOAgent(state_dim=4, device="cpu")
    agent.register_task("old", 3)
    agent.register_task("new", 4)
    agent.set_task("new")
    states = torch.randint(256, (8, 4, 84, 84), dtype=torch.uint8)
    # Establish inherited Adam state before adding the candidate parameters.
    agent.policy_logits(states, "new").square().sum().backward()
    agent.optimizer.step()
    agent.optimizer.zero_grad()
    inherited = copy.deepcopy(agent.optimizer.state_dict())
    spaces = {
        name: {
            "basis": torch.linalg.qr(torch.randn(layer.weight[0].numel() + 1, 2)).Q,
            "importance": torch.ones(2),
        }
        for name, layer in affine_layers(agent.backbone).items()
    }
    agent.add_read_scaling(spaces["7"]["basis"], "new")
    torch.testing.assert_close(agent.optimizer.state_dict()["state"], inherited["state"])
    assert agent.optimizer.param_groups[-1]["params"][0] is agent.backbone[7].scaling
    layer = agent.backbone[7]
    read_weights = layer.read_weights.clone()
    old_heads = copy.deepcopy(agent.actors["old"].state_dict())
    projection = AdamSubspaceProjection(agent.optimizer, agent.backbone, spaces, method="gpm")
    with torch.no_grad():
        actions, logs, values = agent.sample_action_and_value(states)
    data = dict(
        states=states,
        actions=actions,
        log_probs=logs,
        values=values.flatten(),
        rewards=torch.arange(8).float(),
        dones=torch.ones(8),
    )
    try:
        PPOLearner(agent, update_epochs=2, minibatch_size=4).update(
            CollectedRollout(data, torch.zeros(1), 8, ())
        )
        assert projection.steps == 4
        assert layer.scaling.detach().norm() > 0
        assert agent.optimizer.state[layer.scaling]["step"] == 4
        torch.testing.assert_close(layer.read_weights, read_weights, rtol=0, atol=0)
        torch.testing.assert_close(agent.actors["old"].state_dict(), old_heads, rtol=0, atol=0)
        with torch.no_grad():
            old_logits = agent.policy_logits(states, "old").clone()
            new_logits = agent.policy_logits(states, "new").clone()
            saved = layer.scaling.clone()
            layer.scaling.add_(2)
            torch.testing.assert_close(
                agent.policy_logits(states, "old"), old_logits, rtol=0, atol=0
            )
            assert not torch.equal(agent.policy_logits(states, "new"), new_logits)
            layer.scaling.copy_(saved)
        assert agent.current_task == "new" and layer.enabled
        agent.set_task("old")
        assert not layer.enabled
        checkpoint = copy.deepcopy(agent.checkpoint_state())
        restored = SubspaceReadPPOAgent(state_dim=4, device="cpu")
        restored.load_checkpoint_state(checkpoint)
        assert restored.current_task == "old" and not restored.backbone[7].enabled
        torch.testing.assert_close(restored.optimizer.state_dict(), agent.optimizer.state_dict())
        for task in ("old", "new"):
            torch.testing.assert_close(
                restored.policy_logits(states, task),
                agent.policy_logits(states, task),
                rtol=0,
                atol=0,
            )
        restored.set_task("new")
        assert restored.backbone[7].enabled
    finally:
        projection.close()
