"""Behavioral checks for memory bounds and actor-only replay integration."""

from functools import partial

import pytest
import torch
import torch.nn as nn

from algorithms.functional_replay import PolicyMemory, policy_replay_loss
from algorithms.ppo import MultiHeadPPOAgent
from scripts.run_experiments import build_policy_replay_jobs
from scripts.study_policy_replay import normalized_auc
from training.ppo_runtime import CollectedRollout, PPOLearner


def tiny_agent():
    agent = MultiHeadPPOAgent(4, device="cpu")
    agent.backbone = nn.Sequential(nn.Linear(4, 512), nn.Tanh())
    agent.network = agent.backbone
    agent.register_task("old", 3)
    agent.register_task("new", 2)
    agent.set_task("new")
    return agent


def test_memory_is_bounded_task_balanced_and_owns_immutable_targets():
    memory = PolicyMemory(12, seed=1)
    states = torch.arange(80, dtype=torch.uint8).reshape(20, 4)
    teacher = torch.randn(20, 3, requires_grad=True)
    memory.add_task("first", states, teacher)
    stored = memory.tasks["first"][1].clone()
    states.zero_()
    with torch.no_grad():
        teacher.fill_(123)
    torch.testing.assert_close(memory.tasks["first"][1], stored)
    assert not memory.tasks["first"][1].requires_grad
    memory.add_task("second", torch.ones(20, 4, dtype=torch.uint8), torch.randn(20, 2))
    memory.add_task("third", torch.ones(20, 4, dtype=torch.uint8), torch.randn(20, 5))
    assert [len(s) for s, _ in memory.tasks.values()] == [4, 4, 4]
    counts = {task: len(s) for task, s, _ in memory.sample(30000)}
    assert all(9500 < count < 10500 for count in counts.values())
    assert memory.tensor_bytes == 12 * 4 + 4 * (3 + 2 + 5) * 4
    with pytest.raises(ValueError, match="only once"):
        memory.add_task("first", states, teacher)


def test_memory_rng_does_not_perturb_ppo_and_round_trips():
    states, logits = torch.ones(20, 4, dtype=torch.uint8), torch.zeros(20, 2)
    before = torch.get_rng_state().clone()
    memory = PolicyMemory(10, seed=9)
    memory.add_task("old", states, logits)
    memory.sample(8)
    torch.testing.assert_close(before, torch.get_rng_state())
    restored = PolicyMemory.from_state_dict(memory.state_dict())
    for actual, expected in zip(memory.sample(8), restored.sample(8), strict=True):
        assert actual[0] == expected[0]
        for a, b in zip(actual[1:], expected[1:], strict=True):
            torch.testing.assert_close(a, b)


def test_replay_updates_backbone_and_old_actor_without_touching_critics():
    agent = tiny_agent()
    memory = PolicyMemory(8, seed=1)
    states = torch.full((8, 4), 127, dtype=torch.uint8)
    targets = torch.tensor([[3.0, -1.0, 0.0]]).repeat(8, 1)
    memory.add_task("old", states, targets)
    loss = policy_replay_loss(agent, memory, batch_size=8, weight=0.7)
    student = agent.policy_logits(states, "old").log_softmax(-1)
    target = targets.log_softmax(-1)
    expected = 0.7 * (target.exp() * (target - student)).sum(-1).mean()
    torch.testing.assert_close(loss, expected)
    loss.backward()
    assert agent.current_task == "new"
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in agent.backbone.parameters())
    assert all(p.grad is not None for p in agent.actors["old"].parameters())
    assert all(p.grad is None for p in agent.actors["new"].parameters())
    assert all(p.grad is None for p in agent.critics.parameters())


def test_ppo_applies_replay_once_per_minibatch_and_preserves_old_critic():
    agent = tiny_agent()
    states = torch.randint(256, (8, 4), dtype=torch.uint8)
    with torch.no_grad():
        actions, logs, values = agent.sample_action_and_value(states)
    memory = PolicyMemory(8, seed=2)
    memory.add_task("old", states, torch.tensor([[2.0, -1.0, 0.0]]).repeat(8, 1))
    old_actor = agent.actors["old"].weight.detach().clone()
    old_critic = agent.critics["old"].weight.detach().clone()
    replay = partial(policy_replay_loss, agent, memory, batch_size=4, weight=1.0)
    calls = []

    def counted_replay():
        calls.append(1)
        return replay()

    learner = PPOLearner(agent, update_epochs=2, minibatch_size=4, regularizer=counted_replay)
    data = dict(
        states=states,
        actions=actions,
        log_probs=logs,
        values=values.flatten(),
        rewards=torch.arange(8).float(),
        dones=torch.ones(8),
    )
    metrics = learner.update(CollectedRollout(data, torch.zeros(1), 8, ()))
    assert len(calls) == 4
    assert metrics["regularization_loss"] > 0
    assert not torch.equal(old_actor, agent.actors["old"].weight)
    torch.testing.assert_close(old_critic, agent.critics["old"].weight, rtol=0, atol=0)


def test_study_jobs_and_auc_use_individual_seed_and_actual_step_spacing(tmp_path):
    jobs = build_policy_replay_jobs(tmp_path / "config.json", (11, 12))
    assert [j.arguments[-1] for j in jobs] == ["11", "12"]
    assert jobs[0].log_name != jobs[1].log_name
    history = [
        {"steps": 0, "scores": {"task": [0.0, 2.0]}},
        {"steps": 2, "scores": {"task": [3.0]}},
        {"steps": 5, "scores": {"task": [5.0]}},
    ]
    assert normalized_auc(history, "task") == pytest.approx(16 / 5)
