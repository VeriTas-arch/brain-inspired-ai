"""Check functional preservation and Adam-aware projection, not just tensor shapes."""

import copy

import pytest
import torch
import torch.nn as nn

from algorithms.subspace_projection import (
    AdamSubspaceProjection,
    affine_matrix,
    build_input_subspaces,
)
from tests.test_functional_replay import tiny_agent
from training.ppo_runtime import CollectedRollout, PPOLearner


def test_boundary_basis_matches_direct_uncentered_svd_with_bias():
    net = nn.Sequential(nn.Linear(3, 2))
    states = torch.tensor([[255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 128, 0]], dtype=torch.uint8)
    rng = torch.get_rng_state().clone()
    subspace = build_input_subspaces(net, states, threshold=0.95, alpha=25, seed=9)["0"]
    torch.testing.assert_close(rng, torch.get_rng_state())
    x = torch.cat((states.double() / 255, torch.ones(4, 1)), dim=1)
    _, singular, vh = torch.linalg.svd(x)
    rank = int(torch.searchsorted(singular.square().cumsum(0), 0.95 * singular.square().sum())) + 1
    assert subspace["rank"] == rank
    basis = subspace["basis"].double()
    torch.testing.assert_close(basis @ basis.T, vh[:rank].T @ vh[:rank], atol=2e-7, rtol=2e-7)
    expected = 26 * singular[:rank] / (25 * singular[:rank] + singular[0])
    torch.testing.assert_close(subspace["importance"].double(), expected, atol=1e-7, rtol=1e-7)


def test_convolution_uses_receptive_fields_and_one_bias_coordinate():
    net = nn.Sequential(nn.Conv2d(1, 2, 2, stride=2))
    # Every patch is identical, so the rank-one span is known independently.
    states = torch.full((3, 1, 4, 4), 255, dtype=torch.uint8)
    entry = build_input_subspaces(net, states, threshold=0.995, alpha=25, seed=3)["0"]
    assert entry["sample_count"] == 3 * 16
    assert entry["dimension"] == 5
    assert entry["rank"] == 1
    torch.testing.assert_close(entry["basis"] @ entry["basis"].T, torch.full((5, 5), 0.2))


@pytest.mark.parametrize("method", ["gpm", "sgp"])
def test_projected_adam_matches_displacement_formula_with_inherited_moments(method):
    torch.manual_seed(17)
    net = nn.Sequential(nn.Linear(2, 2, dtype=torch.float64))
    optimizer = torch.optim.Adam(net.parameters(), lr=0.01)
    for _ in range(3):
        optimizer.zero_grad()
        net(torch.tensor([[0.5, -1.0]], dtype=torch.float64)).square().sum().backward()
        optimizer.step()
    reference = copy.deepcopy(net)
    raw_optimizer = torch.optim.Adam(reference.parameters(), lr=0.01)
    raw_optimizer.load_state_dict(copy.deepcopy(optimizer.state_dict()))
    basis = torch.linalg.qr(
        torch.tensor([[1.0, 2.0], [2.0, -1.0], [1.0, 1.0]], dtype=torch.float64)
    ).Q
    importance = torch.tensor([1.0, 0.3], dtype=torch.float64)
    subspaces = {"0": {"basis": basis, "importance": importance}}
    before = affine_matrix(net[0]).detach().clone()
    projection = AdamSubspaceProjection(optimizer, net, subspaces, method=method)
    try:
        for model, opt in ((net, optimizer), (reference, raw_optimizer)):
            opt.zero_grad()
            model(torch.tensor([[2.0, 1.0]], dtype=torch.float64)).sum().backward()
            opt.step()
        raw = affine_matrix(reference[0]).detach() - before
        scale = torch.ones_like(importance) if method == "gpm" else importance
        expected = raw - ((raw @ basis) * scale) @ basis.T
        actual = affine_matrix(net[0]).detach() - before
        torch.testing.assert_close(actual, expected, atol=1e-14, rtol=1e-12)
        # The first protected affine input [1, 2, 1] has unchanged output in both methods.
        torch.testing.assert_close(
            actual @ basis[:, 0], torch.zeros(2, dtype=torch.float64), atol=1e-14, rtol=0
        )
        assert actual.norm() > 0
        assert projection.metrics()["optimizer_steps"] == 1
        assert projection.metrics()["layers"]["0"]["projection_relative_error"] < 1e-12
        for p, q in zip(net.parameters(), reference.parameters(), strict=True):
            torch.testing.assert_close(
                optimizer.state[p]["exp_avg"], raw_optimizer.state[q]["exp_avg"]
            )
    finally:
        projection.close()


def test_projecting_raw_gradient_before_adam_does_not_preserve_orthogonality():
    p = nn.Parameter(torch.zeros(2, dtype=torch.float64))
    basis = torch.tensor([1.0, 2.0], dtype=torch.float64)
    basis /= basis.norm()
    gradient = torch.tensor([2.0, -1.0], dtype=torch.float64)
    assert abs(float(gradient @ basis)) < 1e-12
    p.grad = gradient
    torch.optim.Adam([p], lr=0.01).step()
    assert abs(float(p.detach() @ basis)) > 0.001


def test_projection_runs_once_per_ppo_minibatch_and_leaves_old_heads_unchanged():
    agent = tiny_agent()
    states = torch.randint(256, (8, 4), dtype=torch.uint8)
    with torch.no_grad():
        actions, logs, values = agent.sample_action_and_value(states)
    basis = torch.linalg.qr(torch.randn(5, 2)).Q
    projection = AdamSubspaceProjection(
        agent.optimizer,
        agent.backbone,
        {"0": {"basis": basis, "importance": torch.ones(2)}},
        method="gpm",
    )
    old = {k: v.clone() for k, v in agent.actors["old"].state_dict().items()}
    critic = {k: v.clone() for k, v in agent.critics["old"].state_dict().items()}
    new = agent.actors["new"].weight.detach().clone()
    data = dict(
        states=states,
        actions=actions,
        log_probs=logs,
        values=values.flatten(),
        rewards=torch.arange(8).float(),
        dones=torch.ones(8),
    )
    try:
        PPOLearner(agent, update_epochs=2, minibatch_size=4).update(
            CollectedRollout(data, torch.zeros(1), 8, ())
        )
        assert projection.steps == 4
        for k, v in old.items():
            torch.testing.assert_close(v, agent.actors["old"].state_dict()[k], rtol=0, atol=0)
        for k, v in critic.items():
            torch.testing.assert_close(v, agent.critics["old"].state_dict()[k], rtol=0, atol=0)
        assert not torch.equal(new, agent.actors["new"].weight)
    finally:
        projection.close()
